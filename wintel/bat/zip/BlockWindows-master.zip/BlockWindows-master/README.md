# BlockWindows
Stop Windows 7 through 10 Nagging and Spying updates, Tasks, IPs, and services. Works with Windows 7 through 10

FILES
-----

BlockWindows.bat Right Click and "Run as Admin"

hosts.bat Works with Windows 7 and 8. Appends current hosts file. Run from your Downloads directory.
Doesn't work on Windows 10, copy hosts file to your router or firewall if using Windows 10

hosts2.bat Blocks M$ hosts with firewall *BLOCKS most M$ sites OUTLOOK,HOTMAIL,ETC REM any you use*

hosts DNS file of MS hosts to block

hostlist MS Hosts file to blocking for router or firewall use

hosts-dnsmasq Hosts file for dd-wrt and other routers 

HideWindowsUpdates.vbs Hides blocked updates, to reinstall click 'show hidden updates'

DisableWiFiSense.reg Adds registry to disable WiFi Sense, which steals your wifi password without your consent.

DisableGWX.reg Disables Windows Update Nagging Notifications

unblock.bat Unblocks hosts2.bat blocking

JavaScript HashCalc

http://sourceforge.net/projects/hash-calculator/

I created this code from information from:
--

http://www.hakspek.com/security/windows-script-to-remove-all-windows-10-telemetry-updates/

Bitblp

http://serverfault.com/questions/145843/block-specific-windows-update-hotfix/341318

Colin Bowern and Opmet

https://www.astaro.org/gateway-products/web-protection-web-filtering-application-visibility-control/58583-heres-how-block-windows-10-spying-2.html

Pascalgoty and Fuselet

Please submit any updates
-------
https://blockwindows.wordpress.com/
---
PS There is a highly concerted effort by M$ to harass websites that link to this. I'm tired of constantly trying to convince website admins it's not spam.
--
Please repost these URLs many places on social media, blogs, etc. I'm in it for the long haul.
--
https://blockwindows.wordpress.com/

https://github.com/WindowsLies/BlockWindows/

https://gitlab.com/windowslies/blockwindows/

File Mirrors
--
LATEST

http://mir.cr/1CGCWLDG

SHA256 3a2308b59086c6e6dc5734c71a22b0eab3c8289c9f7feb1632b4351247fa341f

OLD

http://www.hakspek.com/wp-content/uploads/2015/08/block_w10.zip

SHA256 5f02ddef572cb408c5a9e44387e7d07ee4c95843edcdc79fa690b5a9910f6c74
