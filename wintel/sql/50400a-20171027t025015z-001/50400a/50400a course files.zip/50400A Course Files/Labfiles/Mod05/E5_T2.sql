USE Mod05
CREATE TABLE TestTable 
(
id int,
content varchar(200),
create_date datetime
)
