<?
/* This file is part of JFFNMS
 * Copyright (C) <2005> Javier Szyszlican <javier@szysz.com>
 * This program is licensed under the GNU GPL, full terms in the LICENSE file
 */

    function trap_receiver_none ($params) {
	// Never Matches
	return array(false, array());
    }
?>
