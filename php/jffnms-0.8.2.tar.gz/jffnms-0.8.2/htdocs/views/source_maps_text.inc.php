<?
/* This file is part of JFFNMS
 * Copyright (C) <2002-2005> Javier Szyszlican <javier@szysz.com>
 * This program is licensed under the GNU GPL, full terms in the LICENSE file
 */
    $item_text ="<b>".str_pad($map_name,30)."</b> ".str_pad("<u>$map_status</u>",20);
?>
