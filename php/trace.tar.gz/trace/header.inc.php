<? require "connect.inc.php"; ?>
<html>
<head><title>Traceroute: browser and admin</title></head>
<body bgcolor=#FFFFFF>
<center>
