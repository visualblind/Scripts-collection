USE Mod05
CREATE TABLE DDL_Log 
(
PostTime datetime, 
DB_User nvarchar (100), 
Event nvarchar (100), 
TSQL nvarchar (2000)
)
