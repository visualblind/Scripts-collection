ALTER TABLE dbo.CallDetailsHistory ADD CONSTRAINT
	PK_CallDetailsHistory PRIMARY KEY CLUSTERED 
	(
	call_date
	) 
ON [PRIMARY]
