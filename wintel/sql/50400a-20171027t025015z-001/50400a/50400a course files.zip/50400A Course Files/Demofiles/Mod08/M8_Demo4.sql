USE QuantamCorp
GO
SELECT * FROM Production.ProductDescription
