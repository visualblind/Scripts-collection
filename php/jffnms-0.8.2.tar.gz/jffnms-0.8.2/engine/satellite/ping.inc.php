<?
/* This file is part of JFFNMS
 * Copyright (C) <2002-2005> Javier Szyszlican <javier@szysz.com>
 * This program is licensed under the GNU GPL, full terms in the LICENSE file
 */
    //a ping system to be sure that the parent can get to the master

    function satellite_ping() { 
	return Array(result=>TRUE);
    }

?>
