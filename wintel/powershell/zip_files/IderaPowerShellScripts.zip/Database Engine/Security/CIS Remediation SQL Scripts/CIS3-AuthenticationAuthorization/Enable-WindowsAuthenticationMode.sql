-- Enable Windows Authentication Mode
-- CIS 3.1 Check (Authentication and Authorization)

USE [master]
GO
EXEC xp_instance_regwrite N'HKEY_LOCAL_MACHINE', N'Software\Microsoft\MSSQLServer\MSSQLServer', N'LoginMode', REG_DWORD, 1
GO