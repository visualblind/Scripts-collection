<?
/* This file is part of JFFNMS
 * Copyright (C) <2002-2005> Javier Szyszlican <javier@szysz.com>
 * This program is licensed under the GNU GPL, full terms in the LICENSE file
 */
    //Make Latest Events	
    //=============================

    //DISABLED because of new filtering on events (FIXME make this an option)
    //$return = make_events_latest($events_latest_max);
    logger("Make Latest Events 1=OK: $return\n");
?>
