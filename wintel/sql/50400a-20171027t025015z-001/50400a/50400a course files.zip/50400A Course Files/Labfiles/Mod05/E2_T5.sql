/*Test the effect of the policy on the CallDetails table*/

USE Mod05 ;
GO
CREATE TABLE CallDetails	
(key_col int) ;
GO

/*Test the effect of the policy on the tb1CallDetails table*/ 

USE Mod05 ;
GO
CREATE TABLE tblCallDetails
(key_col int) ;
GO

