USE Mod07 ;
GO
CREATE TABLE Calls.CallDetails
(key_col int) ;
GO
CREATE TABLE Customers.CustomerInfo
(customer_id int) ;
GO
CREATE TABLE Customers.CustomerAddress
(customer_id int) ;
GO
