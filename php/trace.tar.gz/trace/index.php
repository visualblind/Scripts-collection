<?
include "header.inc.php";
echo "<h2>Traceroute</h2>";

echo "<table><tr><td>";
echo "<li><a href=browser.php>Browse</a>";
echo "<li><a href=admin.php>Admin</a>";
echo "</td></tr></table>";

include "footer.inc.php";
?>