<?
/* This file is part of JFFNMS
 * Copyright (C) <2002-2005> Javier Szyszlican <javier@szysz.com>
 * This program is licensed under the GNU GPL, full terms in the LICENSE file
 */
    //Do Nothing

    function hosts_config_none_get () {
	return NULL;
    }

    function hosts_config_none_wait () {
	return NULL;
    }

?>