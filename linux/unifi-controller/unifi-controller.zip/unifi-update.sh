#!/bin/bash

# UniFi Controller Updater auto installation script.
# Version  | 3.0.12
# Author   | Glenn Rietveld
# Email    | glennrietveld8@hotmail.nl
# Website  | https://GlennR.nl

###################################################################################################################################################################################################
#                                                                                                                                                                                                 #
#                                                                                           Color Codes                                                                                           #
#                                                                                                                                                                                                 #
###################################################################################################################################################################################################

RESET='\033[0m'
GRAY='\033[0;37m'
WHITE='\033[1;37m'
RED='\033[1;31m' # Light Red.
GREEN='\033[1;32m' # Light Green.

###################################################################################################################################################################################################
#                                                                                                                                                                                                 #
#                                                                                           Start Checks                                                                                          #
#                                                                                                                                                                                                 #
###################################################################################################################################################################################################

# Check for root (SUDO).
if [ "$EUID" -ne 0 ]
then
  clear
  echo -e "${RED}#######################################${RESET}"
  echo -e "${RED}#                                     #${RESET}"
  echo -e "${RED}#   ${RESET}Please run this script as root.   ${RED}#${RESET}"
  echo -e "${RED}#                                     #${RESET}"
  echo -e "${RED}#######################################${RESET}"
  exit 1
fi

# Try to install lsb-release
if [ $(dpkg-query -W -f='${Status}' lsb-release 2>/dev/null | grep -c "ok installed") -eq 0 ]
then
  apt-get install lsb-release -y
fi

# Try to install apt-transport-https
if [ $(dpkg-query -W -f='${Status}' apt-transport-https 2>/dev/null | grep -c "ok installed") -eq 0 ]
then
  apt-get install apt-transport-https -y
fi

# Check if UniFi is already installed.
if [ $(dpkg-query -W -f='${Status}' unifi 2>/dev/null | grep -c "ok installed") -eq 0 ]
then
  clear
  echo -e "${RED}#####################################################${RESET}"
  echo -e "${RED}#                                                   #${RESET}"
  echo -e "${RED}#              ${RESET}UniFi isn't installed!               ${RED}#${RESET}"
  echo -e "${RED}#     ${RESET}You can use GlennR's Installation Scripts     ${RED}#${RESET}"
  echo -e "${RED}#          ${RESET}to install UniFi on your system          ${RED}#${RESET}"
  echo -e "${RED}#                                                   #${RESET}"
  echo -e "${RED}#####################################################${RESET}"
  exit 0
fi

###################################################################################################################################################################################################
#                                                                                                                                                                                                 #
#                                                                                            Variables                                                                                            #
#                                                                                                                                                                                                 #
###################################################################################################################################################################################################

UNIFI=$(dpkg -l | grep "unifi " | awk '{print $3}' | sed 's/-.*//')
UNIFI_RELEASE=$(dpkg -l | grep "unifi " | awk '{print $3}' | sed 's/-.*//' | sed 's/\.//g')
OS_NAME=$(lsb_release -cs)
OS_RELEASE=$(lsb_release -rs)
OS_DESC=$(lsb_release -ds)
ARCHITECTURE=$(uname -m)
JAVA7=$(dpkg -l | grep ^ii | grep -c "openjdk-7\|oracle-java7")
JAVA8=$(dpkg -l | grep ^ii | grep -c "openjdk-8\|oracle-java8")

JAVA7_INSTALLED=''
JAVA8_INSTALLED=''
UNIFI_VERSION=''

UNIFI_BACKUP_END=''
UNIFI_BACKUP_TIMED_OUT=''
GLENNR_UNIFI_BACKUP=''
UNIFI_DEVICE_UPGRADE=''
UNIFI_DEVICE_UPGRADE_TIMED_OUT=''
EXECUTED_UNIFI_CREDENTIALS=''
RUN_UNIFI_DEVICES_UPGRADE=''
ONLY_RUN_UNIFI_DEVICES_UPGRADE=''
UNIFI_FIRMWARE_AVAILABLE=''
UNIFI_FIRMWARE_TIMED_OUT=''
run_unifi_devices_upgrade_already=''

# UniFi API Variables
unifi_api_baseurl=https://localhost:8443
unifi_api_cookie=$(mktemp)
unifi_api_curl_cmd="curl --tlsv1 --silent --cookie ${unifi_api_cookie} --cookie-jar ${unifi_api_cookie} --insecure "

# UniFi Devices ( 3.7.58 )
UGW3=(UGW3) 																				#USG3
UGW4=(UGW4) 																				#USGP4
US24P250=(USW US8 US8P60 US8P150 US16P150 US24 US24P250 US24P500 US48 US48P500 US48P750) 	#USW
U7PG2=(U7LT U7LR U7PG2 U7EDU U7MSH U7MP U7IW U7IWP) 										#UAP-AC-Lite/LR/Pro/EDU/M/M-PRO/IW/IW-Pro
BZ2=(BZ2 BZ2LR U2O U5O) 																	#UAP, UAP-LR, UAP-OD, UAP-OD5
U2Sv2=(U2Sv2 U2Lv2) 																		#UAP-v2, UAP-LR-v2
U2IW=(U2IW) 																				#UAP IW
U7P=(U7P) 																					#UAP PRO
U2HSR=(U2HSR) 																				#UAP OD+
U7HD=(U7HD) 																				#UAP HD
USXG=(USXG) 																			 	#USW 16 XG
U7E=(U7E U7Ev2 U7O) 																		#UAP AC, UAP AC v2, UAP AC OD

###################################################################################################################################################################################################
#                                                                                                                                                                                                 #
#                                                                                              ABORT                                                                                              #
#                                                                                                                                                                                                 #
###################################################################################################################################################################################################

abort()
{
echo -e "\n${RED}###############################################################\n\n          An error occurred. Aborting script..\nPlease contact Glenn R. (AmazedMender16) on the Community Forums!\n\n${RESET}"
exit 1
}

###################################################################################################################################################################################################
#                                                                                                                                                                                                 #
#                                                                                            JQ Checks                                                                                            #
#                                                                                                                                                                                                 #
###################################################################################################################################################################################################

if [ $(dpkg-query -W -f='${Status}' jq 2>/dev/null | grep -c "ok installed") -eq 0 ]
then
  echo -e "${GREEN}######################################################${RESET}"
  echo -e "${GREEN}#                                                    #${RESET}"
  echo -e "${GREEN}#           ${RESET}Installing required packages!            ${GREEN}#${RESET}"
  echo -e "${GREEN}#                                                    #${RESET}"
  echo -e "${GREEN}######################################################${RESET}"
  echo ""
  echo ""
  apt-get install jq -y
  if [[ $? > 0 ]]
  then
    if [[ $OS_NAME == "trusty" ]]
	then
      if [[ $(find /etc/apt/* -name *.list | xargs cat | grep -c "^deb http://security.ubuntu.com/ubuntu trusty-security main universe") -eq 0 ]]
	  then
	    echo deb http://security.ubuntu.com/ubuntu trusty-security main universe >>/etc/apt/sources.list.d/glennr-install-script.list || abort
	    apt-get update || abort
	    apt-get install jq -y || abort
	  fi
	elif [[ $OS_NAME == "xenial" ]] || [[ $OS_DESC == "Linux Mint 18"* ]]
	then
      if [[ $(find /etc/apt/* -name *.list | xargs cat | grep -c "^deb http://security.ubuntu.com/ubuntu xenial-security main universe") -eq 0 ]]
	  then
	    echo deb http://security.ubuntu.com/ubuntu xenial-security main universe >>/etc/apt/sources.list.d/glennr-install-script.list || abort
	    apt-get update || abort
	    apt-get install jq -y || abort
	  fi
	elif [[ $OS_NAME == "bionic" ]] || [[ $OS_DESC == "Linux Mint 19"* ]]
	then
      if [[ $(find /etc/apt/* -name *.list | xargs cat | grep -c "^deb http://[A-Za-z0-9]*.archive.ubuntu.com/ubuntu bionic main universe") -eq 0 ]]
	  then
	    echo deb http://nl.archive.ubuntu.com/ubuntu bionic main universe >>/etc/apt/sources.list.d/glennr-install-script.list || abort
	    apt-get update || abort
	    apt-get install jq -y || abort
	  fi
	elif [[ $OS_NAME == "cosmic" ]]
	then
      if [[ $(find /etc/apt/* -name *.list | xargs cat | grep -c "^deb http://[A-Za-z0-9]*.archive.ubuntu.com/ubuntu cosmic main universe") -eq 0 ]]
	  then
	    echo deb http://nl.archive.ubuntu.com/ubuntu cosmic main universe >>/etc/apt/sources.list.d/glennr-install-script.list || abort
	    apt-get update || abort
	    apt-get install jq -y || abort
	  fi
	elif [[ $OS_NAME == "jessie" ]]
	then
      if [[ $(find /etc/apt/* -name *.list | xargs cat | grep -c "^deb http://ftp.[A-Za-z0-9]*.debian.org/debian jessie main") -eq 0 ]]
	  then
	    echo deb http://ftp.nl.debian.org/debian jessie main >>/etc/apt/sources.list.d/glennr-install-script.list || abort
	    apt-get update || abort
	    apt-get install jq -y || abort
	  fi
	elif [[ $OS_NAME == "stretch" ]] || [[ $OS_DESC == "MX 18"* ]]
	then
      if [[ $(find /etc/apt/* -name *.list | xargs cat | grep -c "^deb http://ftp.[A-Za-z0-9]*.debian.org/debian stretch main") -eq 0 ]]
	  then
	    echo deb http://ftp.nl.debian.org/debian stretch main >>/etc/apt/sources.list.d/glennr-install-script.list || abort
	    apt-get update || abort
	    apt-get install jq -y || abort
	  fi
    fi
  fi
fi

###################################################################################################################################################################################################
#                                                                                                                                                                                                 #
#                                                                                                                                                                                                 #
#                                                                                                                                                                                                 #
###################################################################################################################################################################################################

migration_check()
{
clear
echo -e "${GREEN}#########################################################################${RESET}"
echo ""
echo "                 Checking Database migration process."
echo "            This can take up to 2 minutes before timing out!"
echo ""
echo ""
read -t 120 < <(tail -n 0 -f /usr/lib/unifi/logs/server.log | grep --line-buffered 'DB migration to version (.*) is complete\|*** Factory Default ***') && UNIFI_UPDATE=true || TIMED_OUT=true
if [[ $UNIFI_UPDATE = 'true' ]]
then
  clear
  unset UNIFI
  UNIFI=$(dpkg -l | grep "unifi " | awk '{print $3}' | sed 's/-.*//')
  echo -e "${GREEN}#########################################################################${RESET}"
  echo ""
  echo "  UniFi Network Controller DB migration was successful"
  echo -e "  Currently your UniFi Network Controller is on version ${WHITE}$UNIFI${RESET}"
  echo ""
  echo ""
  echo "  Continuing the UniFi Network Controller update!"
  echo ""
  echo ""
  unset UNIFI_UPDATE
  unset TIMED_OUT
  sleep 3
  elif [[ $TIMED_OUT = 'true' ]]
  then
    clear
    echo -e "${RED}#########################################################################${RESET}"
    echo ""
    echo "                      DB migration check timed out!"
    echo ""
    echo "    Please contact Glenn R. (AmazedMender16) on the Community Forums!"
    echo ""
    echo ""
	exit 1
fi
echo ""
echo ""
}

header() {
clear
echo -e "${GREEN}#########################################################################${RESET}"
echo ""
}

unifi_update_start() {
clear
echo -e "${GREEN}#####################################################${RESET}"
echo -e "${GREEN}#                                                   #${RESET}"
echo -e "${GREEN}#   ${RESET}Starting the UniFi Network Controller update!   ${GREEN}#${RESET}"
echo -e "${GREEN}#                                                   #${RESET}"
echo -e "${GREEN}#####################################################${RESET}"
echo ""
echo ""
sleep 2
}

unifi_update_finish() {
unset UNIFI
UNIFI=$(dpkg -l | grep "unifi " | awk '{print $3}' | sed 's/-.*//')
clear
echo -e "${GREEN}###############################################################${RESET}"
echo ""
echo ""
echo -e "${GREEN}#${RESET} Your UniFi Network Controller has been successfully updated to ${WHITE}$UNIFI${RESET}"
echo ""
echo ""
echo -e "${WHITE}#${RESET} ${GRAY}Author   |  ${WHITE}Glenn R.${RESET}"
echo -e "${WHITE}#${RESET} ${GRAY}Email    |  ${WHITE}glennrietveld8@hotmail.nl${RESET}"
echo -e "${WHITE}#${RESET} ${GRAY}Website  |  ${WHITE}https://GlennR.nl${RESET}"
echo ""
echo ""
rm $0
exit 0
}

###################################################################################################################################################################################################
#                                                                                                                                                                                                 #
#                                                                                  UniFi API Login/Logout/Cleanup                                                                                 #
#                                                                                                                                                                                                 #
###################################################################################################################################################################################################

unifi_credentials() {
clear
echo -e "${GREEN}#########################################################################${RESET}"
echo ""
echo -e " ${WHITE}#${RESET} What is your UniFi Network Controller Username?"
echo ""
echo -e " ${RED}#${RESET} Use the Super Administrator credentials!"
echo -e " ${RED}#${RESET} The credentials are used to login to the controller, ${RED}the credentials will not be saved!${RESET}"
echo ""
echo ""
read -p $' Username:\033[1;37m ' username
clear
echo -e "${GREEN}#########################################################################${RESET}"
echo ""
echo -e " ${WHITE}#${RESET} What is your UniFi Network Controller Password?"
echo ""
echo -e " ${RED}#${RESET} Use the Super Administrator credentials!"
echo -e " ${RED}#${RESET} The credentials are used to login to the controller, ${RED}the credentials will not be saved!${RESET}"
echo ""
echo ""
read -sp ' Password: ' password
clear
}

unifi_login() {
	${unifi_api_curl_cmd} --data "{\"username\":\"$username\", \"password\":\"$password\"}" $unifi_api_baseurl/api/login >> /tmp/UniFi-Update-Script-Controller-Login.log
}

unifi_logout() {
    ${unifi_api_curl_cmd} $unifi_api_baseurl/logout
}

unifi_login_check () {
if [[ $(cat /tmp/UniFi-Update-Script-Controller-Login.log | grep "error") ]]
then
  echo -e "${GREEN}################################################################################################################${RESET}"
  echo ""
  echo "                        UniFi Network Controller credentials are incorrect, login failed.."
  echo ""
  echo ""
  read -p $' \033[1;37m#\033[0m Would you like to try again? (Y/n) ' yes_no
  case "$yes_no" in
	[Yy]*|"")
      rm /tmp/UniFi-Update-Script-Controller-Login.log 2> /dev/null
      unset username
      unset password
      unifi_credentials
	  unifi_login
	  unifi_login_check;;
	[Nn]*) ;;
  esac
fi
}

unifi_cleanup() {
    unset username
	unset password
    rm -R /tmp/unifi_site* 2> /dev/null
    rm -R /tmp/unifi_device* 2> /dev/null
    rm -R /tmp/unifi_models 2> /dev/null
    rm -R ${unifi_api_cookie} 2> /dev/null
    rm -R /tmp/UniFi-Update-Script-Controller-Login.log 2> /dev/null
	rm -R /tmp/glennr_custom_upgrade_executed 2> /dev/null
}

###################################################################################################################################################################################################
#                                                                                                                                                                                                 #
#                                                                                      UniFi Devices Upgrade                                                                                      #
#                                                                                                                                                                                                 #
###################################################################################################################################################################################################

unifi_list_sites() {
    echo -e "${GREEN}#########################################################################${RESET}"
    echo ""
    echo -e " ${WHITE}#${RESET} Catching all the site names!"
    echo ""
    echo ""
	sleep 3
    ${unifi_api_curl_cmd} $unifi_api_baseurl/api/stat/sites | jq -r '.data[] .name' >> /tmp/unifi_sites
    cd /tmp; xargs -I {} mkdir -p "unifi_site_{}" < /tmp/unifi_sites; cd ~
}

unifi_upgrade_devices() {
    echo -e "${GREEN}#########################################################################${RESET}"
    echo ""
    echo -e " ${WHITE}#${RESET} Upgrading all the UniFi Devices!!"
    echo ""
    echo ""
	sleep 3
    unifi_api_site=$(tr '\r\n' ' ' < /tmp/unifi_sites)
    for site in ${unifi_api_site[@]}
    do
    ${unifi_api_curl_cmd} $unifi_api_baseurl/api/s/$site/stat/device | jq -r '.data[] | select((.version > "3.8") and (.version < .upgrade_to_firmware)) | .mac' >> /tmp/unifi_site_${site}/unifi_device_mac_addresses
    normal_upgrade=$(tr '\r\n' ' ' < /tmp/unifi_site_${site}/unifi_device_mac_addresses)
    for mac_normal in ${normal_upgrade[@]}
    do
	    ${unifi_api_curl_cmd} --data "{\"mac\":\"${mac_normal}\"}" $unifi_api_baseurl/api/s/${site}/cmd/devmgr/upgrade >> /tmp/unifi_device_normal
    done
	${unifi_api_curl_cmd} $unifi_api_baseurl/api/s/$site/stat/device | jq -r '.data[] | select(.version < "3.8") | .model' >> /tmp/unifi_models
	unifi_api_models=$(tr '\r\n' ' ' < /tmp/unifi_models)
	    for model in ${unifi_api_models[@]}
	    do
	        ${unifi_api_curl_cmd} $unifi_api_baseurl/api/s/$site/stat/device | jq -r '.data[] | select((.version < "3.8") and (.model == "'$model'")) | .mac' >> /tmp/unifi_site_${site}/${model}_unifi_device_mac_addresses
            custom_upgrade_file=(/tmp/unifi_site_${site}/${model}_unifi_device_mac_addresses)
		    if [[ -s $custom_upgrade_file ]]
	        then
			  touch /tmp/glennr_custom_upgrade_executed
			  if [[ ${U7PG2[@]} =~ ${model} ]]
			  then
				custom_upgrade=$(tr '\r\n' ' ' < /tmp/unifi_site_${site}/${model}_unifi_device_mac_addresses)
			    firmware_url=http://dl.ui.com/unifi/firmware/U7PG2/3.9.54.9373/BZ.qca956x.v3.9.54.9373.180914.0009.bin
				for mac_custom in ${custom_upgrade[@]}
				do
				    ${unifi_api_curl_cmd}  --data "{\"url\":\"${firmware_url}\", \"mac\":\"${mac_custom}\"}" $unifi_api_baseurl/api/s/${site}/cmd/devmgr/upgrade-external >> /tmp/unifi_device_custom
				done
                unset firmware_url
			  elif [[ ${BZ2[@]} =~ ${model} ]]
			  then
				custom_upgrade=$(tr '\r\n' ' ' < /tmp/unifi_site_${site}/${model}_unifi_device_mac_addresses)
			    firmware_url=http://dl.ui.com/unifi/firmware/BZ2/3.9.54.9373/BZ.ar7240.v3.9.54.9373.180913.2356.bin
				for mac_custom in ${custom_upgrade[@]}
				do
				    ${unifi_api_curl_cmd}  --data "{\"url\":\"${firmware_url}\", \"mac\":\"${mac_custom}\"}" $unifi_api_baseurl/api/s/${site}/cmd/devmgr/upgrade-external >> /tmp/unifi_device_custom
				done
                unset firmware_url
			  elif [[ ${U2Sv2[@]} =~ ${model} ]]
			  then
				custom_upgrade=$(tr '\r\n' ' ' < /tmp/unifi_site_${site}/${model}_unifi_device_mac_addresses)
			    firmware_url=http://dl.ui.com/unifi/firmware/U2Sv2/3.9.54.9373/BZ.qca9342.v3.9.54.9373.180913.2356.bin
				for mac_custom in ${custom_upgrade[@]}
				do
				    ${unifi_api_curl_cmd}  --data "{\"url\":\"${firmware_url}\", \"mac\":\"${mac_custom}\"}" $unifi_api_baseurl/api/s/${site}/cmd/devmgr/upgrade-external >> /tmp/unifi_device_custom
				done
                unset firmware_url
			  elif [[ ${U2IW[@]} =~ ${model} ]]
			  then
				custom_upgrade=$(tr '\r\n' ' ' < /tmp/unifi_site_${site}/${model}_unifi_device_mac_addresses)
			    firmware_url=http://dl.ui.com/unifi/firmware/U2IW/3.9.54.9373/BZ.qca933x.v3.9.54.9373.180913.2356.bin
				for mac_custom in ${custom_upgrade[@]}
				do
				    ${unifi_api_curl_cmd}  --data "{\"url\":\"${firmware_url}\", \"mac\":\"${mac_custom}\"}" $unifi_api_baseurl/api/s/${site}/cmd/devmgr/upgrade-external >> /tmp/unifi_device_custom
				done
                unset firmware_url
			  elif [[ ${U7P[@]} =~ ${model} ]]
			  then
				custom_upgrade=$(tr '\r\n' ' ' < /tmp/unifi_site_${site}/${model}_unifi_device_mac_addresses)
			    firmware_url=http://dl.ui.com/unifi/firmware/U7P/3.9.54.9373/BZ.ar934x.v3.9.54.9373.180913.2355.bin
				for mac_custom in ${custom_upgrade[@]}
				do
				    ${unifi_api_curl_cmd}  --data "{\"url\":\"${firmware_url}\", \"mac\":\"${mac_custom}\"}" $unifi_api_baseurl/api/s/${site}/cmd/devmgr/upgrade-external >> /tmp/unifi_device_custom
				done
                unset firmware_url
			  elif [[ ${U2HSR[@]} =~ ${model} ]]
			  then
				custom_upgrade=$(tr '\r\n' ' ' < /tmp/unifi_site_${site}/${model}_unifi_device_mac_addresses)
			    firmware_url=http://dl.ui.com/unifi/firmware/U2HSR/3.9.54.9373/BZ.ar7240.v3.9.54.9373.180913.2356.bin
				for mac_custom in ${custom_upgrade[@]}
				do
				    ${unifi_api_curl_cmd}  --data "{\"url\":\"${firmware_url}\", \"mac\":\"${mac_custom}\"}" $unifi_api_baseurl/api/s/${site}/cmd/devmgr/upgrade-external >> /tmp/unifi_device_custom
				done
                unset firmware_url
			  elif [[ ${U7HD[@]} =~ ${model} ]]
			  then
				custom_upgrade=$(tr '\r\n' ' ' < /tmp/unifi_site_${site}/${model}_unifi_device_mac_addresses)
			    firmware_url=http://dl.ui.com/unifi/firmware/U7HD/3.9.54.9373/BZ.ipq806x.v3.9.54.9373.180914.0028.bin
				for mac_custom in ${custom_upgrade[@]}
				do
				    ${unifi_api_curl_cmd}  --data "{\"url\":\"${firmware_url}\", \"mac\":\"${mac_custom}\"}" $unifi_api_baseurl/api/s/${site}/cmd/devmgr/upgrade-external >> /tmp/unifi_device_custom
				done
                unset firmware_url
			  elif [[ ${USXG[@]} =~ ${model} ]]
			  then
				custom_upgrade=$(tr '\r\n' ' ' < /tmp/unifi_site_${site}/${model}_unifi_device_mac_addresses)
			    firmware_url=http://dl.ui.com/unifi/firmware/USXG/3.9.54.9373/US.bcm5341x.v3.9.54.9373.180914.0002.bin
				for mac_custom in ${custom_upgrade[@]}
				do
				    ${unifi_api_curl_cmd}  --data "{\"url\":\"${firmware_url}\", \"mac\":\"${mac_custom}\"}" $unifi_api_baseurl/api/s/${site}/cmd/devmgr/upgrade-external >> /tmp/unifi_device_custom
				done
                unset firmware_url
			  elif [[ ${U7E[@]} =~ ${model} ]]
			  then
				custom_upgrade=$(tr '\r\n' ' ' < /tmp/unifi_site_${site}/${model}_unifi_device_mac_addresses)
			    firmware_url=http://dl.ui.com/unifi/firmware/U7E/3.8.17.6789/BZ.bcm4706.v3.8.17.6789.190110.0913.bin
				for mac_custom in ${custom_upgrade[@]}
				do
				    ${unifi_api_curl_cmd}  --data "{\"url\":\"${firmware_url}\", \"mac\":\"${mac_custom}\"}" $unifi_api_baseurl/api/s/${site}/cmd/devmgr/upgrade-external >> /tmp/unifi_device_custom
				done
                unset firmware_url
              elif [[ ${US24P250[@]} =~ ${model} ]]
              then
				custom_upgrade=$(tr '\r\n' ' ' < /tmp/unifi_site_${site}/${model}_unifi_device_mac_addresses)
                firmware_url=(http://dl.ui.com/unifi/firmware/US24P250/3.9.54.9373/US.bcm5334x.v3.9.54.9373.180914.0005.bin)
                for mac_custom in ${custom_upgrade[@]}
                do
				    ${unifi_api_curl_cmd}  --data "{\"url\":\"${firmware_url}\", \"mac\":\"${mac_custom}\"}" $unifi_api_baseurl/api/s/$site/cmd/devmgr/upgrade-external >> /tmp/unifi_device_custom
                done
                unset firmware_url
			  elif [[ ${UGW3[@]} =~ ${model} ]]
			  then
				custom_upgrade=$(tr '\r\n' ' ' < /tmp/unifi_site_${site}/${model}_unifi_device_mac_addresses)
			    firmware_url=http://dl.ui.com/unifi/firmware/UGW3/4.4.22.5086045/UGW3.v4.4.22.5086045.tar
				for mac_custom in ${custom_upgrade[@]}
				do
				    ${unifi_api_curl_cmd}  --data "{\"url\":\"${firmware_url}\", \"mac\":\"${mac_custom}\"}" $unifi_api_baseurl/api/s/${site}/cmd/devmgr/upgrade-external >> /tmp/unifi_device_custom
				done
                unset firmware_url
			  elif [[ ${UGW4[@]} =~ ${model} ]]
			  then
				custom_upgrade=$(tr '\r\n' ' ' < /tmp/unifi_site_${site}/${model}_unifi_device_mac_addresses)
			    firmware_url=http://dl.ui.com/unifi/firmware/UGW4/4.4.22.5086057/UGW4.v4.4.22.5086057.tar
				for mac_custom in ${custom_upgrade[@]}
				do
				    ${unifi_api_curl_cmd}  --data "{\"url\":\"${firmware_url}\", \"mac\":\"${mac_custom}\"}" $unifi_api_baseurl/api/s/${site}/cmd/devmgr/upgrade-external >> /tmp/unifi_device_custom
				done
                unset firmware_url
			  fi
			fi
		done
    done
	if [[ -f /tmp/unifi_device_normal ]]
	then
	  clear
	  clear
	  echo -e "${GREEN}#########################################################################${RESET}"
      echo ""
      echo "               All the UniFi Devices are now upgrading!"
      echo ""
      echo ""
	else
	  clear
	  clear
	  echo -e "${RED}#########################################################################${RESET}"
      echo ""
      echo "               Can't find any UniFi Devices to upgrade!"
      echo ""
      echo ""
	fi
	sleep 3
}

unifi_custom_upgrade_check () {
  clear
  clear
  echo -e "${GREEN}#########################################################################${RESET}"
  echo ""
  echo -e " ${RED}#${RESET} A custom upgrade has been executed, the script will run one more"
  echo -e " ${RED}#${RESET} time to upgrade everything to the latest available firmware"
  echo ""
  echo -e " ${RED}#${RESET} Waiting for the first device to report back that it upgraded!"
  echo ""
  echo ""
  read -t 900 < <(tail -n 0 -f /usr/lib/unifi/logs/server.log | grep --line-buffered 'was upgraded from ".*" to ".*"') && UNIFI_DEVICE_UPGRADE=true || UNIFI_DEVICE_UPGRADE_TIMED_OUT=true
  if [[ $UNIFI_DEVICE_UPGRADE = 'true' ]]
  then
    echo -e "${GREEN}#########################################################################${RESET}"
    echo ""
    echo -e " ${GREEN}#${RESET} One of the first devices reported back and upgraded!"
    echo -e " ${WHITE}#${RESET} The script will wait 10 minutes to make sure everything gets upgraded."
    echo ""
	sleep 600
    echo ""
    echo -e "${GREEN}#########################################################################${RESET}"
    echo ""
    echo -e " ${GREEN}#${RESET} Starting the second upgrade!"
    echo ""
    echo ""
    sleep 3
	unifi_upgrade_devices
    elif [[ $UNIFI_DEVICE_UPGRADE_TIMED_OUT = 'true' ]]
    then
      clear
      echo -e "${RED}#########################################################################${RESET}"
      echo ""
      echo "                    Device upgrade check timed out!"
      echo ""
      echo "      Please manually check the upgrade status in the controller or"
      echo "        contact Glenn R. (AmazedMender16) on the Community Forums!"
      echo ""
      echo ""
	  exit 1
  fi
}

###################################################################################################################################################################################################
#                                                                                                                                                                                                 #
#                                                                                          UniFi Backup                                                                                           #
#                                                                                                                                                                                                 #
###################################################################################################################################################################################################

unifi_backup () {
    clear
    clear
    echo -e "${GREEN}#########################################################################${RESET}"
    echo ""
    echo -e " ${WHITE}#${RESET} Creating the backup!"
	echo -e " ${WHITE}#${RESET} This can take a while for big controllers!"
    echo ""
    echo ""
	if [[ -d /data/autobackup/ ]]
	then
	  if [[ ! -d /data/autobackup/glennr-unifi-backups/ ]]
	  then
	    mkdir /data/autobackup/glennr-unifi-backups/
	  fi
      output=/data/autobackup/glennr-unifi-backups/unifi_api_${UNIFI}_`date +%Y%m%d%H%M`.unf
	else
	  if [[ ! -d /usr/lib/unifi/data/backup/autobackup/glennr-unifi-backups/ ]]
	  then
	    mkdir /usr/lib/unifi/data/backup/autobackup/glennr-unifi-backups/
	  fi
      output=/usr/lib/unifi/data/backup/autobackup/glennr-unifi-backups/unifi_backup_${UNIFI}_`date +%Y%m%d%H%M`.unf
	fi
	path=`$unifi_api_curl_cmd --data "{\"cmd\":\"backup\"}" $unifi_api_baseurl/api/s/default/cmd/backup | sed -n 's/.*\(\/dl.*unf\).*/\1/p'`
	$unifi_api_curl_cmd $unifi_api_baseurl$path -o $output --create-dirs
}

unifi_backup_check () {
    clear
    clear
    echo -e "${GREEN}#########################################################################${RESET}"
    echo ""
    echo -e " ${WHITE}#${RESET} Checking if the backup got created!"
    echo -e " ${WHITE}#${RESET} This can take up to 5 minutes before timing out!"
    echo ""
    echo ""
    read -t 300 < <(tail -n 1000 -f /usr/lib/unifi/logs/server.log | grep --line-buffered 'BACKUP.* end') && UNIFI_BACKUP_END=true || UNIFI_BACKUP_TIMED_OUT=true
	if [[ $UNIFI_BACKUP_END = 'true' ]]
	then
	  GLENNR_UNIFI_BACKUP=success
      clear
	  clear
      echo -e "${GREEN}#########################################################################${RESET}"
      echo ""
      echo "            UniFi Network Controller backup was successful!"
      echo ""
      echo ""
	  sleep 3
	elif [[ $UNIFI_BACKUP_TIMED_OUT = 'true' ]]
	then
	  clear
	  clear
      echo -e "${RED}#########################################################################${RESET}"
      echo ""
      echo "            UniFi Network Controller Backup check timed out!"
      echo ""
      echo ""
	  sleep 3
	fi
}

###################################################################################################################################################################################################
#                                                                                                                                                                                                 #
#                                                                                     Ask For Device Upgrade                                                                                      #
#                                                                                                                                                                                                 #
###################################################################################################################################################################################################

run_unifi_devices_upgrade () {
    clear
    echo -e "${GREEN}#########################################################################${RESET}"
	echo ""
	echo -e " ${WHITE}#${RESET} Starting the devices updates!"
	echo ""
	echo ""
	sleep 5
    #run_unifi_devices_upgrade_already=true
    if [[ $EXECUTED_UNIFI_CREDENTIALS != 'true' ]]
	then
	  unifi_credentials
	  EXECUTED_UNIFI_CREDENTIALS=true
	fi
	unifi_login
	unifi_login_check
	unifi_list_sites
	unifi_upgrade_devices
	if [[ -f /tmp/glennr_custom_upgrade_executed ]]
	then
	  unifi_custom_upgrade_check
	fi
	unifi_logout
}

only_run_unifi_devices_upgrade () {
    clear
    echo -e "${GREEN}#########################################################################${RESET}"
	echo ""
	echo -e " ${WHITE}#${RESET} Starting the devices updates!"
	echo ""
	echo ""
	sleep 5
	unifi_credentials
	unifi_login
	unifi_login_check
	unifi_list_sites
	unifi_upgrade_devices
	if [[ -f /tmp/glennr_custom_upgrade_executed ]]
	then
	  unifi_custom_upgrade_check
	fi
	unifi_logout
	unifi_cleanup
	rm $0
	exit 0
}

###################################################################################################################################################################################################
#                                                                                                                                                                                                 #
#                                                                                         5.10.x Upgrades                                                                                         #
#                                                                                                                                                                                                 #
###################################################################################################################################################################################################

unifi_5_10_x_upgrade () {
	#if [[ $run_unifi_devices_upgrade_already != 'true' ]]
	#then
	  clear
	  clear
	  echo -e "${GREEN}################################################################################################################${RESET}"
	  echo ""
	  echo -e " ${WHITE}#${RESET} The script is about to upgrade the UniFi Network controller to 5.10.x." 
	  echo ""
	  echo -e " ${WHITE}#${RESET} The required minimum firmware for UAP/USW is 4.0.9 and 4.4.34 for the USG."
	  echo -e " ${WHITE}#${RESET} Devices on earlier firmware will show in the controller and work as you've configured them,"
	  echo -e " ${WHITE}#${RESET} this update doesn't change any of the settings. However, please note you will not be able"
	  echo -e " ${WHITE}#${RESET} to modify the device configuration until you update the firmware."
	  echo ""
	  echo -e " ${RED}#${RESET} Would you like the script to execute the upgrade commands?"
	  echo ""
	  echo ""
	  read -p $' \033[1;37m#\033[0m Do you want to proceed with upgrading the devices? (Y/n) ' yes_no
	  case "$yes_no" in
		  [Yy]*|"")
 	        echo -e "${GREEN}#########################################################################${RESET}"
 	        echo ""
 	        echo -e " ${WHITE}#${RESET} Checking if the firmware is available!"
			echo -e " ${WHITE}#${RESET} This can take up to 5 minutes before timing out!"
 	        echo ""
 	        echo ""
 	        sleep 5
 	        read -t 300 < <(tail -n 0 -f /usr/lib/unifi/logs/server.log | grep --line-buffered 'firmware.* new version (.*) is available') && UNIFI_FIRMWARE_AVAILABLE=true || UNIFI_FIRMWARE_TIMED_OUT=true
			if [[ $UNIFI_FIRMWARE_AVAILABLE = 'true' ]]
			then
 	          run_unifi_devices_upgrade
			elif [[ $UNIFI_FIRMWARE_TIMED_OUT = 'true' ]]
			then
			  echo -e "${RED}#########################################################################${RESET}"
			  echo ""
 	          echo "               UniFi Firmware Available check timed out!"
			  echo ""
			  echo "             Running the devices upgrade without the check"
			  echo ""
			  echo ""
			  sleep 5
			  run_unifi_devices_upgrade
			fi;;
		  [Nn]*)
		    clear
	        echo -e "${RED}#####################################################${RESET}"
	        echo -e "${RED}#                                                   #${RESET}"
	        echo -e "${RED}#         ${RESET}Upgrading the controller without          ${RED}#${RESET}"
		    echo -e "${RED}#               ${RESET}touching the devices!               ${RED}#${RESET}"
	        echo -e "${RED}#                                                   #${RESET}"
	        echo -e "${RED}#####################################################${RESET}"
	        sleep 3;;
	  esac
	#fi
}

###################################################################################################################################################################################################
#                                                                                                                                                                                                 #
#                                                                                       What Should we run?                                                                                       #
#                                                                                                                                                                                                 #
###################################################################################################################################################################################################

clear
clear
echo -e "${GREEN}#########################################################################${RESET}"
echo ""
echo "  What do you want to update?"
echo ""
echo ""
echo -e " [ ${WHITE}1${RESET} ]  |  UniFi Network Controller"
echo -e " [ ${WHITE}2${RESET} ]  |  UniFi Devices ( on all sites )"
echo -e " [ ${WHITE}3${RESET} ]  |  Both"
echo -e " [ ${WHITE}4${RESET} ]  |  Cancel"
echo ""
echo ""
read UNIFI_EASY_UPDATE
case "$UNIFI_EASY_UPDATE" in
  1*)
     ;;
  2*)
	 only_run_unifi_devices_upgrade;;
  3*)
	 run_unifi_devices_upgrade;;
  4|*)
	 exit 0;;
esac

###################################################################################################################################################################################################
#                                                                                                                                                                                                 #
#                                                                                         Ask For Backup                                                                                          #
#                                                                                                                                                                                                 #
###################################################################################################################################################################################################

clear
clear
echo -e "${GREEN}################################################################################################################${RESET}"
echo ""
echo "                    Would you like to create a backup of your UniFi Network Controller?"
echo ""
echo -e "                                ${RED}I highly recommend creating a backup!${RESET}"
echo ""
echo ""
read -p $' \033[1;37m#\033[0m Do you want to proceed with creating a backup? (Y/n) ' yes_no
case "$yes_no" in
	[Yy]*|"")
	  clear
	  echo -e "${GREEN}#########################################################################${RESET}"
	  echo ""
	  echo -e " ${WHITE}#${RESET} Starting the controller backup!"
	  echo ""
	  echo ""
	  sleep 5
      if [[ $EXECUTED_UNIFI_CREDENTIALS != 'true' ]]
	  then
	    unifi_credentials
	    EXECUTED_UNIFI_CREDENTIALS=true
	  fi
      unifi_login
	  unifi_login_check
      unifi_backup
      unifi_logout
	  unifi_backup_check
	  unifi_cleanup;;
	[Nn]*)
	  clear
      echo -e "${RED}#####################################################${RESET}"
      echo -e "${RED}#                                                   #${RESET}"
      echo -e "${RED}#        ${RESET}You choose not to create a backup!         ${RED}#${RESET}"
      echo -e "${RED}#                                                   #${RESET}"
      echo -e "${RED}#####################################################${RESET}"
      sleep 3
	  unifi_cleanup;;
esac

if [[ $GLENNR_UNIFI_BACKUP = 'success' ]]
then
  if [[ -d /data/autobackup/glennr-unifi-backups/ ]]
  then
    chown -R unifi:unifi /data/autobackup/glennr-unifi-backups/
  fi
  if [[ -d /usr/lib/unifi/data/backup/autobackup/glennr-unifi-backups/ ]]
  then
    chown -R unifi:unifi /usr/lib/unifi/data/backup/autobackup/glennr-unifi-backups/
  fi
fi

###################################################################################################################################################################################################
#                                                                                                                                                                                                 #
#                                                                                             Checks                                                                                              #
#                                                                                                                                                                                                 #
###################################################################################################################################################################################################


if [[ $GLENNR_UNIFI_BACKUP != 'success' ]]
then
  clear
  echo -e "${RED}################################################################################################################${RESET}"
  echo ""
  echo "                         You didn't create a backup of your UniFi Network Controller!"
  echo ""
  echo ""
  read -p $' \033[1;37m#\033[0m Do you want to proceed with updating your UniFi Network Controller? (Y/n) ' yes_no
  case "$yes_no" in
	[Yy]*|"")
	  clear
      echo -e "${GREEN}#####################################################${RESET}"
      echo -e "${GREEN}#                                                   #${RESET}"
      echo -e "${GREEN}#   ${RESET}Starting the UniFi Network Controller update!   ${GREEN}#${RESET}"
      echo -e "${GREEN}#                                                   #${RESET}"
      echo -e "${GREEN}#    ${RESET}Thank you for using my Easy Update Script!     ${GREEN}#${RESET}"
      echo -e "${GREEN}#                                                   #${RESET}"
      echo -e "${GREEN}#####################################################${RESET}"
	  echo ""
	  echo ""
      sleep 3;;
	[Nn]*)
	  clear
      echo -e "${RED}#####################################################${RESET}"
      echo -e "${RED}#                                                   #${RESET}"
      echo -e "${RED}#           ${RESET}You didn't download a backup!           ${RED}#${RESET}"
      echo -e "${RED}#   ${RESET}Please download a backup and rerun the script   ${RED}#${RESET}"
      echo -e "${RED}#                                                   #${RESET}"
      echo -e "${RED}#              ${RESET}Cancelling the script!               ${RED}#${RESET}"
      echo -e "${RED}#                                                   #${RESET}"
      echo -e "${RED}#####################################################${RESET}"
	  echo ""
	  echo ""
      exit 1;;
  esac
fi

if [ -f /etc/apt/sources.list.d/100-ubnt-unifi.list ] || [[ $(cat /etc/apt/sources.list | grep "ubnt.com/download\|ui.com/download") ]]
then
  clear
  sed -i '/unifi/d' /etc/apt/sources.list
  rm /etc/apt/sources.list.d/100-ubnt-unifi.list
  echo -e "${RED}#####################################################${RESET}"
  echo -e "${RED}#                                                   #${RESET}"
  echo -e "${RED}# ${RESET}UniFi source files were detected on your system!  ${RED}#${RESET}"
  echo -e "${RED}#      ${RESET}Removing the source files, to make sure      ${RED}#${RESET}"
  echo -e "${RED}#          ${RESET}your update will be successful!          ${RED}#${RESET}"
  echo -e "${RED}#                                                   #${RESET}"
  echo -e "${RED}#####################################################${RESET}"
  sleep 5
  clear
fi

if [ -f unifi_sysvinit_all.deb ]
then
  clear
  rm unifi_sysvinit_all.deb*
  echo -e "${RED}#####################################################${RESET}"
  echo -e "${RED}#                                                   #${RESET}"
  echo -e "${RED}#      ${RESET}UniFi Installation files were detected!      ${RED}#${RESET}"
  echo -e "${RED}#   ${RESET}Removing the installation files, to make sure   ${RED}#${RESET}"
  echo -e "${RED}#          ${RESET}your update will be successful!          ${RED}#${RESET}"
  echo -e "${RED}#                                                   #${RESET}"
  echo -e "${RED}#####################################################${RESET}"
  sleep 5
  clear
fi
  
if [[ $JAVA8 -eq 0 ]]
then
    clear
    echo -e "${RED}################################################${RESET}"
	echo -e "${RED}#${RESET}                                              ${RED}#${RESET}"
    echo -e "${RED}#${RESET}           JAVA 8 is not installed!           ${RED}#${RESET}"
    echo -e "${RED}#${RESET}            Installing OpenJDK 8!             ${RED}#${RESET}"
	echo -e "${RED}#${RESET}                                              ${RED}#${RESET}"
	echo -e "${RED}################################################${RESET}"
    echo ""
    echo ""
    sleep 2
	if [[ $OS_NAME == "trusty" ]]
    then
	  clear
      echo -e "${GREEN}################################################${RESET}"
      echo -e "${GREEN}#${RESET}                                              ${GREEN}#${RESET}"
      echo -e "${GREEN}#${RESET}             Selected OS  ${WHITE}Trusty              ${GREEN}#${RESET}"
      echo -e "${GREEN}#${RESET}                                              ${GREEN}#${RESET}"
      echo -e "${GREEN}################################################${RESET}"
      sleep 2
      if [[ $(cat /etc/environment | grep "JAVA_HOME") ]]
      then
        sed -i 's/^JAVA_HOME/#JAVA_HOME/' /etc/environment
      fi
      if [ $(dpkg-query -W -f='${Status}' openjdk-8-jre-headless 2>/dev/null | grep -c "ok installed") -eq 0 ]
      then
        apt-get install openjdk-8-jre-headless --force-yes || apt-get install openjdk-8-jre-headless -y
        if [[ $? > 0 ]]
        then
          if [[ $(find /etc/apt/* -name *.list | xargs cat | grep -c "^deb http://ppa.launchpad.net/openjdk-r/ppa/ubuntu trusty main") -eq 0 ]]
          then
            echo deb http://ppa.launchpad.net/openjdk-r/ppa/ubuntu trusty main >>/etc/apt/sources.list.d/glennr-install-script.list || abort
            apt-get update || abort
      	    apt-get install openjdk-8-jre-headless --force-yes || apt-get install openjdk-8-jre-headless -y || abort
          fi
        fi
      fi
      if [[ $? > 0 ]]
      then
	    clear
        echo -e "${RED}########################################################${RESET}"
        echo -e "${RED}#                                                      #${RESET}"
        echo -e "${RED}#            ${RESET}Failed to install OpenJDK 8!              ${RED}#${RESET}"
        echo -e "${RED}#                ${RESET}Trying Orcale JAVA 8!                 ${RED}#${RESET}"
        echo -e "${RED}#                                                      #${RESET}"
        echo -e "${RED}########################################################${RESET}"
        sleep 2
        apt-get purge openjdk-8-jre-headless --force-yes || apt-get purge openjdk-8-jre-headless -y
		apt-add-repository ppa:webupd8team/java --force-yes || apt-add-repository ppa:webupd8team/java -y || abort
        apt-get update || abort
        echo "oracle-java8-installer shared/accepted-oracle-license-v1-1 select true" | debconf-set-selections || abort
        apt-get install oracle-java8-installer --force-yes; apt-get install oracle-java8-set-default --force-yes || apt-get install oracle-java8-installer -y; apt-get install oracle-java8-set-default -y
      fi
      if [[ $(dpkg-query -W -f='${Status}' oracle-java8-installer 2>/dev/null | grep -c "ok installed") -eq 1 ]] || [[ $(dpkg-query -W -f='${Status}' openjdk-8-jre-headless 2>/dev/null | grep -c "ok installed") -eq 1 ]]
      then
	    if [ -f /etc/default/unifi ]
		then
		  if [[ $(cat /etc/default/unifi | grep "JAVA_HOME") ]]
          then
            sed -i 's/^JAVA_HOME/#JAVA_HOME/' /etc/default/unifi
          fi
          echo "JAVA_HOME="$( readlink -f "$( which java )" | sed "s:bin/.*$::" )"" >> /etc/default/unifi
		else
	      echo "JAVA_HOME="$( readlink -f "$( which java )" | sed "s:bin/.*$::" )"" >> /etc/environment
	      source /etc/environment
		fi
      fi
    elif [[ $OS_NAME == "xenial" ]] || [[ $OS_DESC == "Linux Mint 18"* ]]
    then
      echo -e "${GREEN}################################################${RESET}"
      echo -e "${GREEN}#${RESET}                                              ${GREEN}#${RESET}"
      echo -e "${GREEN}#${RESET}             Selected OS  ${WHITE}Xenial              ${GREEN}#${RESET}"
      echo -e "${GREEN}#${RESET}                                              ${GREEN}#${RESET}"
      echo -e "${GREEN}################################################${RESET}"
      sleep 2
      if [[ $(cat /etc/environment | grep "JAVA_HOME") ]]
      then
        sed -i 's/^JAVA_HOME/#JAVA_HOME/' /etc/environment
      fi
      if [ $(dpkg-query -W -f='${Status}' openjdk-8-jre-headless 2>/dev/null | grep -c "ok installed") -eq 0 ]
      then
        apt-get install openjdk-8-jre-headless -y
        if [[ $? > 0 ]]
        then
          if [[ $(find /etc/apt/* -name *.list | xargs cat | grep -c "^deb http://security.ubuntu.com/ubuntu xenial-security main universe") -eq 0 ]]
          then
            echo deb http://security.ubuntu.com/ubuntu xenial-security main universe >>/etc/apt/sources.list.d/glennr-install-script.list || abort
            apt-get update || abort
      	    apt-get install openjdk-8-jre-headless -y || abort
          fi
        fi
      fi
      if [[ $? > 0 ]]
      then
	    clear
        echo -e "${RED}########################################################${RESET}"
        echo -e "${RED}#                                                      #${RESET}"
        echo -e "${RED}#            ${RESET}Failed to install OpenJDK 8!              ${RED}#${RESET}"
        echo -e "${RED}#                ${RESET}Trying Orcale JAVA 8!                 ${RED}#${RESET}"
        echo -e "${RED}#                                                      #${RESET}"
        echo -e "${RED}########################################################${RESET}"
        sleep 2
        apt-get purge openjdk-8-jre-headless -y
		add-apt-repository ppa:webupd8team/java -y || abort
        apt-get update || abort
        echo "oracle-java8-installer shared/accepted-oracle-license-v1-1 select true" | debconf-set-selections || abort
        apt-get install oracle-java8-installer -y; apt-get install oracle-java8-set-default -y
      fi
      if [[ $(dpkg-query -W -f='${Status}' oracle-java8-installer 2>/dev/null | grep -c "ok installed") -eq 1 ]] || [[ $(dpkg-query -W -f='${Status}' openjdk-8-jre-headless 2>/dev/null | grep -c "ok installed") -eq 1 ]]
      then
	    if [ -f /etc/default/unifi ]
		then
		  if [[ $(cat /etc/default/unifi | grep "JAVA_HOME") ]]
          then
            sed -i 's/^JAVA_HOME/#JAVA_HOME/' /etc/default/unifi
          fi
          echo "JAVA_HOME="$( readlink -f "$( which java )" | sed "s:bin/.*$::" )"" >> /etc/default/unifi
		else
	      echo "JAVA_HOME="$( readlink -f "$( which java )" | sed "s:bin/.*$::" )"" >> /etc/environment
	      source /etc/environment
		fi
      fi
    elif [[ $OS_NAME == "bionic" ]] || [[ $OS_DESC == "Linux Mint 19"* ]]
    then
      echo -e "${GREEN}################################################${RESET}"
      echo -e "${GREEN}#${RESET}                                              ${GREEN}#${RESET}"
      echo -e "${GREEN}#${RESET}             Selected OS  ${WHITE}Bionic              ${GREEN}#${RESET}"
      echo -e "${GREEN}#${RESET}                                              ${GREEN}#${RESET}"
      echo -e "${GREEN}################################################${RESET}"
      sleep 2
      if [[ $(cat /etc/environment | grep "JAVA_HOME") ]]
      then
        sed -i 's/^JAVA_HOME/#JAVA_HOME/' /etc/environment
      fi
      if [ $(dpkg-query -W -f='${Status}' openjdk-8-jre-headless 2>/dev/null | grep -c "ok installed") -eq 0 ]
      then
        apt-get install openjdk-8-jre-headless -y
        if [[ $? > 0 ]]
        then
          if [[ $(find /etc/apt/* -name *.list | xargs cat | grep -c "^deb http://security.ubuntu.com/ubuntu bionic-security main universe") -eq 0 ]]
          then
            echo deb http://security.ubuntu.com/ubuntu bionic-security main universe >>/etc/apt/sources.list.d/glennr-install-script.list || abort
            apt-get update || abort
      	    apt-get install openjdk-8-jre-headless -y || abort
          fi
        fi
      fi
      if [[ $? > 0 ]]
      then
	    clear
        echo -e "${RED}########################################################${RESET}"
        echo -e "${RED}#                                                      #${RESET}"
        echo -e "${RED}#            ${RESET}Failed to install OpenJDK 8!              ${RED}#${RESET}"
        echo -e "${RED}#                ${RESET}Trying Orcale JAVA 8!                 ${RED}#${RESET}"
        echo -e "${RED}#                                                      #${RESET}"
        echo -e "${RED}########################################################${RESET}"
        sleep 2
        apt-get purge openjdk-8-jre-headless -y
        add-apt-repository ppa:webupd8team/java -y || abort
        apt-get update || abort
        echo "oracle-java8-installer shared/accepted-oracle-license-v1-1 select true" | debconf-set-selections || abort
        apt-get install oracle-java8-installer -y; apt-get install oracle-java8-set-default -y
      fi
      if [[ $(dpkg-query -W -f='${Status}' oracle-java8-installer 2>/dev/null | grep -c "ok installed") -eq 1 ]] || [[ $(dpkg-query -W -f='${Status}' openjdk-8-jre-headless 2>/dev/null | grep -c "ok installed") -eq 1 ]]
      then
	    if [ -f /etc/default/unifi ]
		then
		  if [[ $(cat /etc/default/unifi | grep "JAVA_HOME") ]]
          then
            sed -i 's/^JAVA_HOME/#JAVA_HOME/' /etc/default/unifi
          fi
          echo "JAVA_HOME="$( readlink -f "$( which java )" | sed "s:bin/.*$::" )"" >> /etc/default/unifi
		else
	      echo "JAVA_HOME="$( readlink -f "$( which java )" | sed "s:bin/.*$::" )"" >> /etc/environment
	      source /etc/environment
		fi
      fi
    elif [[ $OS_NAME == "cosmic" ]]
    then
      echo -e "${GREEN}################################################${RESET}"
      echo -e "${GREEN}#${RESET}                                              ${GREEN}#${RESET}"
      echo -e "${GREEN}#${RESET}             Selected OS  ${WHITE}Cosmic              ${GREEN}#${RESET}"
      echo -e "${GREEN}#${RESET}                                              ${GREEN}#${RESET}"
      echo -e "${GREEN}################################################${RESET}"
      sleep 2
      if [[ $(cat /etc/environment | grep "JAVA_HOME") ]]
      then
        sed -i 's/^JAVA_HOME/#JAVA_HOME/' /etc/environment
      fi
      if [ $(dpkg-query -W -f='${Status}' openjdk-8-jre-headless 2>/dev/null | grep -c "ok installed") -eq 0 ]
      then
        apt-get install openjdk-8-jre-headless -y
        if [[ $? > 0 ]]
        then
          if [[ $(find /etc/apt/* -name *.list | xargs cat | grep -c "^deb http://security.ubuntu.com/ubuntu cosmic-security main universe") -eq 0 ]]
          then
            echo deb http://security.ubuntu.com/ubuntu cosmic-security main universe >>/etc/apt/sources.list.d/glennr-install-script.list || abort
            apt-get update || abort
      	    apt-get install openjdk-8-jre-headless -y || abort
          fi
        fi
      fi
      if [[ $? > 0 ]]
      then
	    clear
        echo -e "${RED}########################################################${RESET}"
        echo -e "${RED}#                                                      #${RESET}"
        echo -e "${RED}#            ${RESET}Failed to install OpenJDK 8!              ${RED}#${RESET}"
        echo -e "${RED}#                ${RESET}Trying Orcale JAVA 8!                 ${RED}#${RESET}"
        echo -e "${RED}#                                                      #${RESET}"
        echo -e "${RED}########################################################${RESET}"
        sleep 2
        apt-get purge openjdk-8-jre-headless -y
        add-apt-repository ppa:webupd8team/java -y || abort
        apt-get update || abort
        echo "oracle-java8-installer shared/accepted-oracle-license-v1-1 select true" | debconf-set-selections || abort
        apt-get install oracle-java8-installer -y; apt-get install oracle-java8-set-default -y
      fi
      if [[ $(dpkg-query -W -f='${Status}' oracle-java8-installer 2>/dev/null | grep -c "ok installed") -eq 1 ]] || [[ $(dpkg-query -W -f='${Status}' openjdk-8-jre-headless 2>/dev/null | grep -c "ok installed") -eq 1 ]]
      then
	    if [ -f /etc/default/unifi ]
		then
		  if [[ $(cat /etc/default/unifi | grep "JAVA_HOME") ]]
          then
            sed -i 's/^JAVA_HOME/#JAVA_HOME/' /etc/default/unifi
          fi
          echo "JAVA_HOME="$( readlink -f "$( which java )" | sed "s:bin/.*$::" )"" >> /etc/default/unifi
		else
	      echo "JAVA_HOME="$( readlink -f "$( which java )" | sed "s:bin/.*$::" )"" >> /etc/environment
	      source /etc/environment
		fi
      fi
    elif [[ $OS_NAME == "jessie" ]]
    then
      echo -e "${GREEN}################################################${RESET}"
      echo -e "${GREEN}#${RESET}                                              ${GREEN}#${RESET}"
      echo -e "${GREEN}#${RESET}             Selected OS  ${WHITE}Jessie              ${GREEN}#${RESET}"
      echo -e "${GREEN}#${RESET}                                              ${GREEN}#${RESET}"
      echo -e "${GREEN}################################################${RESET}"
      sleep 2
      if [[ $(cat /etc/environment | grep "JAVA_HOME") ]]
      then
        sed -i 's/^JAVA_HOME/#JAVA_HOME/' /etc/environment
      fi
      if [ $(dpkg-query -W -f='${Status}' openjdk-8-jre-headless 2>/dev/null | grep -c "ok installed") -eq 0 ]
      then
        apt-get install -t jessie-backports openjdk-8-jre-headless ca-certificates-java -y
        if [[ $? > 0 ]]
        then
          if [[ $(find /etc/apt/* -name *.list | xargs cat | grep -P -c "^deb http://ftp.[A-Za-z0-9]*.debian.org/debian jessie-backports main") -eq 0 ]]
          then
            echo deb http://ftp.nl.debian.org/debian jessie-backports main >>/etc/apt/sources.list.d/glennr-install-script.list || abort
            apt-get update || abort
      	    apt-get install -t jessie-backports openjdk-8-jre-headless ca-certificates-java -y || abort
      	  fi
        fi
      fi
      if [[ $? > 0 ]]
      then
	    clear
        echo -e "${RED}########################################################${RESET}"
        echo -e "${RED}#                                                      #${RESET}"
        echo -e "${RED}#            ${RESET}Failed to install OpenJDK 8!              ${RED}#${RESET}"
        echo -e "${RED}#                ${RESET}Trying Orcale JAVA 8!                 ${RED}#${RESET}"
        echo -e "${RED}#                                                      #${RESET}"
        echo -e "${RED}########################################################${RESET}"
        sleep 2
        apt-get purge openjdk-8-jre-headless -y
        add-apt-repository "deb http://ppa.launchpad.net/webupd8team/java/ubuntu xenial main" || abort
        apt-get update || abort
        echo "oracle-java8-installer shared/accepted-oracle-license-v1-1 select true" | debconf-set-selections || abort
        apt-get install oracle-java8-installer -y; apt-get install oracle-java8-set-default -y
      fi
      if [[ $(dpkg-query -W -f='${Status}' oracle-java8-installer 2>/dev/null | grep -c "ok installed") -eq 1 ]] || [[ $(dpkg-query -W -f='${Status}' openjdk-8-jre-headless 2>/dev/null | grep -c "ok installed") -eq 1 ]]
      then
	    if [ -f /etc/default/unifi ]
		then
		  if [[ $(cat /etc/default/unifi | grep "JAVA_HOME") ]]
          then
            sed -i 's/^JAVA_HOME/#JAVA_HOME/' /etc/default/unifi
          fi
          echo "JAVA_HOME="$( readlink -f "$( which java )" | sed "s:bin/.*$::" )"" >> /etc/default/unifi
		else
	      echo "JAVA_HOME="$( readlink -f "$( which java )" | sed "s:bin/.*$::" )"" >> /etc/environment
	      source /etc/environment
		fi
      fi
    elif [[ $OS_NAME == "stretch" ]] || [[ $OS_DESC == "MX 18"* ]]
    then
      echo -e "${GREEN}################################################${RESET}"
      echo -e "${GREEN}#${RESET}                                              ${GREEN}#${RESET}"
      echo -e "${GREEN}#${RESET}             Selected OS  ${WHITE}Stretch             ${GREEN}#${RESET}"
      echo -e "${GREEN}#${RESET}                                              ${GREEN}#${RESET}"
      echo -e "${GREEN}################################################${RESET}"
      sleep 2
      if [[ $(cat /etc/environment | grep "JAVA_HOME") ]]
      then
        sed -i 's/^JAVA_HOME/#JAVA_HOME/' /etc/environment
      fi
      if [ $(dpkg-query -W -f='${Status}' openjdk-8-jre-headless 2>/dev/null | grep -c "ok installed") -eq 0 ]
      then
        apt-get install openjdk-8-jre-headless ca-certificates-java -y
        if [[ $? > 0 ]]
        then
          if [[ $(find /etc/apt/* -name *.list | xargs cat | grep -P -c "^deb http://ftp.[A-Za-z0-9]*.debian.org/debian stretch main") -eq 0 ]]
          then
            echo deb http://ftp.nl.debian.org/debian stretch main >>/etc/apt/sources.list.d/glennr-install-script.list || abort
            apt-get update || abort
      	    apt-get install openjdk-8-jre-headless ca-certificates-java -y || abort
      	  fi
        fi
      fi
      if [[ $? > 0 ]]
      then
	    clear
        echo -e "${RED}########################################################${RESET}"
        echo -e "${RED}#                                                      #${RESET}"
        echo -e "${RED}#            ${RESET}Failed to install OpenJDK 8!              ${RED}#${RESET}"
        echo -e "${RED}#                ${RESET}Trying Orcale JAVA 8!                 ${RED}#${RESET}"
        echo -e "${RED}#                                                      #${RESET}"
        echo -e "${RED}########################################################${RESET}"
        sleep 2
        apt-get purge openjdk-8-jre-headless -y
        add-apt-repository ppa:webupd8team/java -y; apt-key adv --keyserver keyserver.ubuntu.com --recv-keys C2518248EEA14886 || abort
        apt-get update || abort
        echo "oracle-java8-installer shared/accepted-oracle-license-v1-1 select true" | debconf-set-selections || abort
        apt-get install oracle-java8-installer -y; apt-get install oracle-java8-set-default -y
      fi
      if [[ $(dpkg-query -W -f='${Status}' oracle-java8-installer 2>/dev/null | grep -c "ok installed") -eq 1 ]] || [[ $(dpkg-query -W -f='${Status}' openjdk-8-jre-headless 2>/dev/null | grep -c "ok installed") -eq 1 ]]
      then
	    if [ -f /etc/default/unifi ]
		then
		  if [[ $(cat /etc/default/unifi | grep "JAVA_HOME") ]]
          then
            sed -i 's/^JAVA_HOME/#JAVA_HOME/' /etc/default/unifi
          fi
          echo "JAVA_HOME="$( readlink -f "$( which java )" | sed "s:bin/.*$::" )"" >> /etc/default/unifi
		else
	      echo "JAVA_HOME="$( readlink -f "$( which java )" | sed "s:bin/.*$::" )"" >> /etc/environment
	      source /etc/environment
		fi
      fi
    else
      echo ""
      echo -e "${RED}###############################################################${RESET}"
      echo ""
      echo ""
      echo -e "      ${RED}Please manually install JAVA 8 on your system!${RESET}"
      echo ""
      echo -e "      ${GRAY}OS Details:${RESET}"
      echo ""
      echo -e "      ${RED}${OS_DESC}${RESET}"
	  echo ""
	  exit 0
    fi
fi

# JAVA 7 Check
JAVA7=$(dpkg -l | grep ^ii | grep -c "openjdk-7\|oracle-java7")
JAVA8=$(dpkg -l | grep ^ii | grep -c "openjdk-8\|oracle-java8")

if [[ $JAVA8 -eq 1 ]]
then
  JAVA8_INSTALLED=true
fi
if [[ $JAVA7 -eq 1 ]]
then
  JAVA7_INSTALLED=true
fi

if [[ ( $JAVA8_INSTALLED = 'true' && $JAVA7_INSTALLED = 'true' ) ]]
then
  echo -e "${RED}################################################################################################################${RESET}"
  echo ""
  echo "                                 JAVA 8 was installed on your system!"
  echo "                                   Do you want to uninstall JAVA 7?"
  echo ""
  echo "                   ! This will also uninstall any other package depending on JAVA 7 !"
  echo ""
  echo ""
  read -p $' \033[1;37m#\033[0m Do you want to proceed with uninstalling JAVA 7? (Y/n) ' yes_no
  case "$yes_no" in
	  [Yy]*|"")
		clear
        echo -e "${GREEN}#####################################################${RESET}"
        echo -e "${GREEN}#                                                   #${RESET}"
        echo -e "${GREEN}#               ${RESET}Uninstalling JAVA 7!                ${GREEN}#${RESET}"
        echo -e "${GREEN}#                                                   #${RESET}"
        echo -e "${GREEN}#####################################################${RESET}"
        apt-get purge openjdk-7-* -y || apt-get purge oracle-java7-* -y;;
	  [Nn]*)
		clear
        echo -e "${RED}#####################################################${RESET}"
        echo -e "${RED}#                                                   #${RESET}"
        echo -e "${RED}#              ${RESET}Cancelling the script!               ${RED}#${RESET}"
        echo -e "${RED}#                                                   #${RESET}"
        echo -e "${RED}#####################################################${RESET}"
        exit 1;;
  esac
fi

##########################################################################################################################################################################
#																																										 #
#																       5.0.x																							 #
#																																										 #
##########################################################################################################################################################################

if [[ $UNIFI = "5.0."* ]]
then
  clear
  echo -e "${GREEN}#########################################################################${RESET}"
  echo ""
  echo "  To what UniFi Network Controller version would you like to update?"
  echo -e "  Currently your UniFi Network Controller is on version ${WHITE}$UNIFI${RESET}"
  echo ""
  echo ""
  echo -e " [ ${WHITE}1${RESET} ]  |  5.6.40 ( UAP-AC, UAP-AC v2, UAP-AC-OD )"
  echo -e " [ ${WHITE}2${RESET} ]  |  5.8.30"
  echo -e " [ ${WHITE}3${RESET} ]  |  5.9.29"
  echo -e " [ ${WHITE}4${RESET} ]  |  5.10.20"
  echo -e " [ ${WHITE}5${RESET} ]  |  Cancel"
  echo ""
  echo ""

  read UPGRADE_VERSION
  case "$UPGRADE_VERSION" in
	1|5640|5.6.40)
	   unifi_update_start
	   if [[ $UNIFI < "5.0.7" ]]
	   then
	     header
	     wget https://www.ubnt.com/downloads/unifi/5.0.7/unifi_sysvinit_all.deb || abort
		 DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
		 rm unifi_sysvinit_all.deb || abort
		 migration_check
	   fi
	   header
       wget https://www.ubnt.com/downloads/unifi/5.2.9/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://www.ubnt.com/downloads/unifi/5.3.11/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.4.19/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.5.24/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.6.40/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       unifi_update_finish;;
	2|5830|5.8.30)
       unifi_update_start
       if [[ $UNIFI < "5.0.7" ]]
       then
	     header
		 wget https://www.ubnt.com/downloads/unifi/5.0.7/unifi_sysvinit_all.deb || abort
		 DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
		 rm unifi_sysvinit_all.deb || abort
		 migration_check
	   fi
	   header
       wget https://www.ubnt.com/downloads/unifi/5.2.9/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://www.ubnt.com/downloads/unifi/5.3.11/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.4.19/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.5.24/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.6.40/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.8.30/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       unifi_update_finish;;
	3|5929|5.9.29)
       unifi_update_start
       if [[ $UNIFI < "5.0.7" ]]
       then
	     header
		 wget https://www.ubnt.com/downloads/unifi/5.0.7/unifi_sysvinit_all.deb || abort
		 DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
		 rm unifi_sysvinit_all.deb || abort
		 migration_check
       fi
	   header
       wget https://www.ubnt.com/downloads/unifi/5.2.9/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://www.ubnt.com/downloads/unifi/5.3.11/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.4.19/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.5.24/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.6.40/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.8.30/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.9.29/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       unifi_update_finish;;
	4|51020|5.10.20)
       unifi_update_start
       if [[ $UNIFI < "5.0.7" ]]
       then
	     header
		 wget https://www.ubnt.com/downloads/unifi/5.0.7/unifi_sysvinit_all.deb || abort
		 DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
		 rm unifi_sysvinit_all.deb || abort
		 migration_check
       fi
	   header
       wget https://www.ubnt.com/downloads/unifi/5.2.9/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://www.ubnt.com/downloads/unifi/5.3.11/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.4.19/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.5.24/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.6.40/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.8.30/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.9.29/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   unifi_5_10_x_upgrade
	   header
       wget https://dl.ui.com/unifi/5.10.20/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       unifi_update_finish;;
	5|*)
	   echo "Cancelling the script!"
	   exit 1;;
  esac
fi

##########################################################################################################################################################################
#																																										 #
#																       5.2.x																							 #
#																																										 #
##########################################################################################################################################################################

if [[ $UNIFI = "5.2."* ]]
then
  clear
  echo -e "${GREEN}#########################################################################${RESET}"
  echo ""
  echo "  To what UniFi Network Controller version would you like to update?"
  echo -e "  Currently your UniFi Network Controller is on version ${WHITE}$UNIFI${RESET}"
  echo ""
  echo ""
  echo -e " [ ${WHITE}1${RESET} ]  |  5.6.40 ( UAP-AC, UAP-AC v2, UAP-AC-OD )"
  echo -e " [ ${WHITE}2${RESET} ]  |  5.8.30"
  echo -e " [ ${WHITE}3${RESET} ]  |  5.9.29"
  echo -e " [ ${WHITE}4${RESET} ]  |  5.10.20"
  echo -e " [ ${WHITE}5${RESET} ]  |  Cancel"
  echo ""
  echo ""

  read UPGRADE_VERSION
  case "$UPGRADE_VERSION" in
	1|5640|5.6.40)
       unifi_update_start
       if [[ $UNIFI < "5.2.9" ]]
       then
	     header
         wget https://www.ubnt.com/downloads/unifi/5.2.9/unifi_sysvinit_all.deb || abort
         DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
         rm unifi_sysvinit_all.deb || abort
         migration_check
       fi
	   header
       wget https://www.ubnt.com/downloads/unifi/5.3.11/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.4.19/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.5.24/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.6.40/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       unifi_update_finish;;
	2|5830|5.8.30)
	   unifi_update_start
       if [[ $UNIFI < "5.2.9" ]]
       then
	     header
         wget https://www.ubnt.com/downloads/unifi/5.2.9/unifi_sysvinit_all.deb || abort
         DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
         rm unifi_sysvinit_all.deb || abort
         migration_check
       fi
	   header
       wget https://www.ubnt.com/downloads/unifi/5.3.11/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.4.19/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.5.24/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.6.40/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.8.30/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       unifi_update_finish;;
	3|5929|5.9.29)
	   unifi_update_start
       if [[ $UNIFI < "5.2.9" ]]
       then
	    header
         wget https://www.ubnt.com/downloads/unifi/5.2.9/unifi_sysvinit_all.deb || abort
         DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
         rm unifi_sysvinit_all.deb || abort
         migration_check
       fi
	   header
       wget https://www.ubnt.com/downloads/unifi/5.3.11/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.4.19/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.5.24/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.6.40/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.8.30/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.9.29/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       unifi_update_finish;;
	4|51020|5.10.20)
	   unifi_update_start
       if [[ $UNIFI < "5.2.9" ]]
       then
	    header
         wget https://www.ubnt.com/downloads/unifi/5.2.9/unifi_sysvinit_all.deb || abort
         DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
         rm unifi_sysvinit_all.deb || abort
         migration_check
       fi
	   header
       wget https://www.ubnt.com/downloads/unifi/5.3.11/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.4.19/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.5.24/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.6.40/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.8.30/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.9.29/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   unifi_5_10_x_upgrade
	   header
       wget https://dl.ui.com/unifi/5.10.20/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       unifi_update_finish;;
	5|*)
	   echo "Cancelling the script!"
	   exit 1;;
  esac
fi

##########################################################################################################################################################################
#																																										 #
#																       5.3.x																							 #
#																																										 #
##########################################################################################################################################################################

if [[ $UNIFI = "5.3."* ]]
then
  clear
  echo -e "${GREEN}#########################################################################${RESET}"
  echo ""
  echo "  To what UniFi Network Controller version would you like to update?"
  echo -e "  Currently your UniFi Network Controller is on version ${WHITE}$UNIFI${RESET}"
  echo ""
  echo ""
  echo -e " [ ${WHITE}1${RESET} ]  |  5.6.40 ( UAP-AC, UAP-AC v2, UAP-AC-OD )"
  echo -e " [ ${WHITE}2${RESET} ]  |  5.8.30"
  echo -e " [ ${WHITE}3${RESET} ]  |  5.9.29"
  echo -e " [ ${WHITE}4${RESET} ]  |  5.10.20"
  echo -e " [ ${WHITE}5${RESET} ]  |  Cancel"
  echo ""
  echo ""

  read UPGRADE_VERSION
  case "$UPGRADE_VERSION" in
	1|5640|5.6.40)
	   unifi_update_start
       if [[ $UNIFI < "5.3.11" ]]
       then
	     header
         wget https://www.ubnt.com/downloads/unifi/5.3.11/unifi_sysvinit_all.deb || abort
         DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
         rm unifi_sysvinit_all.deb || abort
         migration_check
       fi
	   header
       wget https://dl.ui.com/unifi/5.4.19/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.5.24/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.6.40/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       unifi_update_finish;;
	2|5830|5.8.30)
	   unifi_update_start
       if [[ $UNIFI < "5.3.11" ]]
       then
	     header
         wget https://www.ubnt.com/downloads/unifi/5.3.11/unifi_sysvinit_all.deb || abort
         DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
         rm unifi_sysvinit_all.deb || abort
         migration_check
       fi
	   header
       wget https://dl.ui.com/unifi/5.4.19/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.5.24/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.6.40/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.8.30/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       unifi_update_finish;;
	3|5929|5.9.29)
	   unifi_update_start
       if [[ $UNIFI < "5.3.11" ]]
       then
	     header
         wget https://www.ubnt.com/downloads/unifi/5.3.11/unifi_sysvinit_all.deb || abort
         DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
         rm unifi_sysvinit_all.deb || abort
         migration_check
       fi
	   header
       wget https://dl.ui.com/unifi/5.4.19/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.5.24/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.6.40/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.8.30/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.9.29/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       unifi_update_finish;;
	4|51020|5.10.20)
	   unifi_update_start
       if [[ $UNIFI < "5.3.11" ]]
       then
	     header
         wget https://www.ubnt.com/downloads/unifi/5.3.11/unifi_sysvinit_all.deb || abort
         DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
         rm unifi_sysvinit_all.deb || abort
         migration_check
       fi
	   header
       wget https://dl.ui.com/unifi/5.4.19/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.5.24/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.6.40/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.8.30/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.9.29/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   unifi_5_10_x_upgrade
	   header
       wget https://dl.ui.com/unifi/5.10.20/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       unifi_update_finish;;
	5|*)
	   echo "Cancelling the script!"
	   exit 1;;
  esac
fi

##########################################################################################################################################################################
#																																										 #
#																       5.4.x																							 #
#																																										 #
##########################################################################################################################################################################

if [[ $UNIFI = "5.4."* ]]
then
  clear
  echo -e "${GREEN}#########################################################################${RESET}"
  echo ""
  echo "  To what UniFi Network Controller version would you like to update?"
  echo -e "  Currently your UniFi Network Controller is on version ${WHITE}$UNIFI${RESET}"
  echo ""
  echo ""
  echo -e " [ ${WHITE}1${RESET} ]  |  5.6.40 ( UAP-AC, UAP-AC v2, UAP-AC-OD )"
  echo -e " [ ${WHITE}2${RESET} ]  |  5.8.30"
  echo -e " [ ${WHITE}3${RESET} ]  |  5.9.29"
  echo -e " [ ${WHITE}4${RESET} ]  |  5.10.20"
  echo -e " [ ${WHITE}5${RESET} ]  |  Cancel"
  echo ""
  echo ""

  read UPGRADE_VERSION
  case "$UPGRADE_VERSION" in
	1|5640|5.6.40)
	   unifi_update_start
       if [[ $UNIFI < "5.4.19" ]]
       then
	     header
         wget https://dl.ui.com/unifi/5.4.19/unifi_sysvinit_all.deb || abort
         DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
         rm unifi_sysvinit_all.deb || abort
         migration_check
       fi
	   header
       wget https://dl.ui.com/unifi/5.5.24/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.6.40/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       unifi_update_finish;;
	2|5830|5.8.30)
	   unifi_update_start
       if [[ $UNIFI < "5.4.19" ]]
       then
	     header
         wget https://dl.ui.com/unifi/5.4.19/unifi_sysvinit_all.deb || abort
         DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
         rm unifi_sysvinit_all.deb || abort
         migration_check
       fi
	   header
       wget https://dl.ui.com/unifi/5.5.24/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.6.40/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.8.30/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       unifi_update_finish;;
	3|5929|5.9.29)
	   unifi_update_start
       if [[ $UNIFI < "5.4.19" ]]
       then
	     header
         wget https://dl.ui.com/unifi/5.4.19/unifi_sysvinit_all.deb || abort
         DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
         rm unifi_sysvinit_all.deb || abort
         migration_check
       fi
	   header
       wget https://dl.ui.com/unifi/5.5.24/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.6.40/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.8.30/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.9.29/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       unifi_update_finish;;
	4|51020|5.10.20)
	   unifi_update_start
       if [[ $UNIFI < "5.4.19" ]]
       then
	     header
         wget https://dl.ui.com/unifi/5.4.19/unifi_sysvinit_all.deb || abort
         DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
         rm unifi_sysvinit_all.deb || abort
         migration_check
       fi
	   header
       wget https://dl.ui.com/unifi/5.5.24/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.6.40/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.8.30/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.9.29/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   unifi_5_10_x_upgrade
	   header
       wget https://dl.ui.com/unifi/5.10.20/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       unifi_update_finish;;
	5|*)
	   echo "Cancelling the script!"
	   exit 1;;
  esac
fi

##########################################################################################################################################################################
#																																										 #
#																       5.5.x																							 #
#																																										 #
##########################################################################################################################################################################

if [[ $UNIFI = "5.5."* ]]
then
  clear
  echo -e "${GREEN}#########################################################################${RESET}"
  echo ""
  echo "  To what UniFi Network Controller version would you like to update?"
  echo -e "  Currently your UniFi Network Controller is on version ${WHITE}$UNIFI${RESET}"
  echo ""
  echo ""
  echo -e " [ ${WHITE}1${RESET} ]  |  5.6.40 ( UAP-AC, UAP-AC v2, UAP-AC-OD )"
  echo -e " [ ${WHITE}2${RESET} ]  |  5.8.30"
  echo -e " [ ${WHITE}3${RESET} ]  |  5.9.29"
  echo -e " [ ${WHITE}4${RESET} ]  |  5.10.20"
  echo -e " [ ${WHITE}5${RESET} ]  |  Cancel"
  echo ""
  echo ""

  read UPGRADE_VERSION
  case "$UPGRADE_VERSION" in
	1|5640|5.6.40)
	   unifi_update_start
       if [[ $UNIFI < "5.5.24" ]]
       then
	     header
         wget https://dl.ui.com/unifi/5.5.24/unifi_sysvinit_all.deb || abort
         DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
         rm unifi_sysvinit_all.deb || abort
         migration_check
       fi
	   header
       wget https://dl.ui.com/unifi/5.6.40/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       unifi_update_finish;;
	2|5830|5.8.30)
	   unifi_update_start
       if [[ $UNIFI < "5.5.24" ]]
       then
	     header
         wget https://dl.ui.com/unifi/5.5.24/unifi_sysvinit_all.deb || abort
         DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
         rm unifi_sysvinit_all.deb || abort
         migration_check
       fi
	   header
       wget https://dl.ui.com/unifi/5.6.40/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.8.30/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       unifi_update_finish;;
	3|5929|5.9.29)
	   unifi_update_start
       if [[ $UNIFI < "5.5.24" ]]
       then
	     header
         wget https://dl.ui.com/unifi/5.5.24/unifi_sysvinit_all.deb || abort
         DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
         rm unifi_sysvinit_all.deb || abort
         migration_check
       fi
	   header
       wget https://dl.ui.com/unifi/5.6.40/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.8.30/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.9.29/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       unifi_update_finish;;
	4|51020|5.10.20)
	   unifi_update_start
       if [[ $UNIFI < "5.5.24" ]]
       then
	     header
         wget https://dl.ui.com/unifi/5.5.24/unifi_sysvinit_all.deb || abort
         DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
         rm unifi_sysvinit_all.deb || abort
         migration_check
       fi
	   header
       wget https://dl.ui.com/unifi/5.6.40/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.8.30/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.9.29/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   unifi_5_10_x_upgrade
	   header
       wget https://dl.ui.com/unifi/5.10.20/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       unifi_update_finish;;
	5|*)
	   echo "Cancelling the script!"
	   exit 1;;
  esac
fi

##########################################################################################################################################################################
#																																										 #
#																       5.6.x																							 #
#																																										 #
##########################################################################################################################################################################

if [[ $UNIFI = "5.6."* ]]
then
  clear
  echo -e "${GREEN}#########################################################################${RESET}"
  echo ""
  echo "  To what UniFi Network Controller version would you like to update?"
  echo -e "  Currently your UniFi Network Controller is on version ${WHITE}$UNIFI${RESET}"
  echo ""
  echo ""
  if [[ $UNIFI = "5.6.40" ]]
  then
    UNIFI_VERSION='5.6.40'
    echo -e " [ ${WHITE}1${RESET} ]  |  5.8.30"
    echo -e " [ ${WHITE}2${RESET} ]  |  5.9.29"
    echo -e " [ ${WHITE}3${RESET} ]  |  5.10.20"
	echo -e " [ ${WHITE}4${RESET} ]  |  Cancel"
  else
    echo -e " [ ${WHITE}1${RESET} ]  |  5.6.40 ( UAP-AC, UAP-AC v2, UAP-AC-OD )"
    echo -e " [ ${WHITE}2${RESET} ]  |  5.8.30"
    echo -e " [ ${WHITE}3${RESET} ]  |  5.9.29"
    echo -e " [ ${WHITE}4${RESET} ]  |  5.10.20"
    echo -e " [ ${WHITE}5${RESET} ]  |  Cancel"
  fi
  echo ""
  echo ""

  if [[ $UNIFI_VERSION = "5.6.40" ]]
  then
    read UPGRADE_VERSION
    case "$UPGRADE_VERSION" in
	  1|5830|5.8.30)
	     unifi_update_start
		 header
         wget https://dl.ui.com/unifi/5.8.30/unifi_sysvinit_all.deb || abort
         DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
         rm unifi_sysvinit_all.deb || abort
         unifi_update_finish;;
	  2|5929|5.9.29)
	     unifi_update_start
		 header
         wget https://dl.ui.com/unifi/5.8.30/unifi_sysvinit_all.deb || abort
         DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
         rm unifi_sysvinit_all.deb || abort
         migration_check
		 header
         wget https://dl.ui.com/unifi/5.9.29/unifi_sysvinit_all.deb || abort
         DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
         rm unifi_sysvinit_all.deb || abort
         unifi_update_finish;;
	  3|51020|5.10.20)
	     unifi_update_start
		 header
         wget https://dl.ui.com/unifi/5.8.30/unifi_sysvinit_all.deb || abort
         DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
         rm unifi_sysvinit_all.deb || abort
         migration_check
		 header
         wget https://dl.ui.com/unifi/5.9.29/unifi_sysvinit_all.deb || abort
         DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
         rm unifi_sysvinit_all.deb || abort
         migration_check
		 unifi_5_10_x_upgrade
		 header
         wget https://dl.ui.com/unifi/5.10.20/unifi_sysvinit_all.deb || abort
         DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
         rm unifi_sysvinit_all.deb || abort
         unifi_update_finish;;
	  4|*)
	     echo "Cancelling the script!"
		 exit 1;;
    esac
  else
    read UPGRADE_VERSION
    case "$UPGRADE_VERSION" in
	  1|5640|5.6.40)
	     unifi_update_start
		 header
         wget https://dl.ui.com/unifi/5.6.40/unifi_sysvinit_all.deb || abort
         DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
         rm unifi_sysvinit_all.deb || abort
         unifi_update_finish;;
	  2|5830|5.8.30)
	     unifi_update_start
		 header
         wget https://dl.ui.com/unifi/5.6.40/unifi_sysvinit_all.deb || abort
         DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
         rm unifi_sysvinit_all.deb || abort
		 migration_check
		 header
         wget https://dl.ui.com/unifi/5.8.30/unifi_sysvinit_all.deb || abort
         DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
         rm unifi_sysvinit_all.deb || abort
         unifi_update_finish;;
	  3|5929|5.9.29)
	     unifi_update_start
		 header
         wget https://dl.ui.com/unifi/5.6.40/unifi_sysvinit_all.deb || abort
         DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
         rm unifi_sysvinit_all.deb || abort
		 migration_check
		 header
         wget https://dl.ui.com/unifi/5.8.30/unifi_sysvinit_all.deb || abort
         DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
         rm unifi_sysvinit_all.deb || abort
         migration_check
		 header
         wget https://dl.ui.com/unifi/5.9.29/unifi_sysvinit_all.deb || abort
         DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
         rm unifi_sysvinit_all.deb || abort
         unifi_update_finish;;
	  4|51020|5.10.20)
	     unifi_update_start
		 header
         wget https://dl.ui.com/unifi/5.6.40/unifi_sysvinit_all.deb || abort
         DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
         rm unifi_sysvinit_all.deb || abort
		 header
         wget https://dl.ui.com/unifi/5.8.30/unifi_sysvinit_all.deb || abort
         DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
         rm unifi_sysvinit_all.deb || abort
         migration_check
		 header
         wget https://dl.ui.com/unifi/5.9.29/unifi_sysvinit_all.deb || abort
         DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
         rm unifi_sysvinit_all.deb || abort
         migration_check
		 unifi_5_10_x_upgrade
		 header
         wget https://dl.ui.com/unifi/5.10.20/unifi_sysvinit_all.deb || abort
         DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
         rm unifi_sysvinit_all.deb || abort
         unifi_update_finish;;
	  5|*)
	     echo "Cancelling the script!"
		 exit 1;;
    esac
  fi
fi

##########################################################################################################################################################################
#																																										 #
#																       5.7.x																							 #
#																																										 #
##########################################################################################################################################################################

if [[ $UNIFI = "5.7."* ]]
then
  clear
  echo -e "${GREEN}#########################################################################${RESET}"
  echo ""
  echo "  To what UniFi Network Controller version would you like to update?"
  echo -e "  Currently your UniFi Network Controller is on version ${WHITE}$UNIFI${RESET}"
  echo ""
  echo ""
  echo -e " [ ${WHITE}1${RESET} ]  |  5.8.30"
  echo -e " [ ${WHITE}2${RESET} ]  |  5.9.29"
  echo -e " [ ${WHITE}3${RESET} ]  |  5.10.20"
  echo -e " [ ${WHITE}4${RESET} ]  |  Cancel"
  echo ""
  echo ""

  read UPGRADE_VERSION
  case "$UPGRADE_VERSION" in
	1|5830|5.8.30)
	   unifi_update_start
	   header
       wget https://dl.ui.com/unifi/5.8.30/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       unifi_update_finish;;
	2|5929|5.9.29)
	   unifi_update_start
       header
       wget https://dl.ui.com/unifi/5.8.30/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.9.29/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       unifi_update_finish;;
	3|51020|5.10.20)
	   unifi_update_start
	   header
       wget https://dl.ui.com/unifi/5.8.30/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   header
       wget https://dl.ui.com/unifi/5.9.29/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       migration_check
	   unifi_5_10_x_upgrade
	   header
       wget https://dl.ui.com/unifi/5.10.20/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       unifi_update_finish;;
	4|*)
	   echo "Cancelling the script!"
	   exit 1;;
  esac
fi

##########################################################################################################################################################################
#																																										 #
#																       5.8.x																							 #
#																																										 #
##########################################################################################################################################################################

if [[ $UNIFI = "5.8."* ]]
then
  clear
  echo -e "${GREEN}#########################################################################${RESET}"
  echo ""
  echo "  To what UniFi Network Controller version would you like to update?"
  echo -e "  Currently your UniFi Network Controller is on version ${WHITE}$UNIFI${RESET}"
  echo ""
  echo ""
  if [[ $UNIFI = "5.8.30" ]]
  then
    UNIFI_VERSION='5.8.30'
    echo -e " [ ${WHITE}1${RESET} ]  |  5.9.29"
    echo -e " [ ${WHITE}2${RESET} ]  |  5.10.20"
    echo -e " [ ${WHITE}3${RESET} ]  |  Cancel"
  else
    echo -e " [ ${WHITE}1${RESET} ]  |  5.8.30"
    echo -e " [ ${WHITE}2${RESET} ]  |  5.9.29"
    echo -e " [ ${WHITE}3${RESET} ]  |  5.10.20"
    echo -e " [ ${WHITE}4${RESET} ]  |  Cancel"
  fi
  echo ""
  echo ""

  if [[ $UNIFI_VERSION = "5.8.30" ]]
  then
    read UPGRADE_VERSION
    case "$UPGRADE_VERSION" in
	  1|5929|5.9.29)
	     unifi_update_start
		 header
         wget https://dl.ui.com/unifi/5.9.29/unifi_sysvinit_all.deb || abort
         DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
         rm unifi_sysvinit_all.deb || abort
         unifi_update_finish;;
	  2|51020|5.10.20)
	     unifi_update_start
		 header
         wget https://dl.ui.com/unifi/5.9.29/unifi_sysvinit_all.deb || abort
         DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
         rm unifi_sysvinit_all.deb || abort
         migration_check
		 unifi_5_10_x_upgrade
		 header
         wget https://dl.ui.com/unifi/5.10.20/unifi_sysvinit_all.deb || abort
         DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
         rm unifi_sysvinit_all.deb || abort
         unifi_update_finish;;
	  3|*)
	     echo "Cancelling the script!"
		 exit 1;;
    esac
  else
    read UPGRADE_VERSION
    case "$UPGRADE_VERSION" in
	  1|5830|5.8.30)
	     unifi_update_start
		 header
         wget https://dl.ui.com/unifi/5.8.30/unifi_sysvinit_all.deb || abort
         DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
         rm unifi_sysvinit_all.deb || abort
         unifi_update_finish;;
	  2|5929|5.9.29)
	     unifi_update_start
		 header
         wget https://dl.ui.com/unifi/5.8.30/unifi_sysvinit_all.deb || abort
         DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
         rm unifi_sysvinit_all.deb || abort
         migration_check
		 header
         wget https://dl.ui.com/unifi/5.9.29/unifi_sysvinit_all.deb || abort
         DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
         rm unifi_sysvinit_all.deb || abort
         unifi_update_finish;;
	  3|51020|5.10.20)
	     unifi_update_start
		 header
         wget https://dl.ui.com/unifi/5.8.30/unifi_sysvinit_all.deb || abort
         DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
         rm unifi_sysvinit_all.deb || abort
         migration_check
		 header
         wget https://dl.ui.com/unifi/5.9.29/unifi_sysvinit_all.deb || abort
         DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
         rm unifi_sysvinit_all.deb || abort
         migration_check
		 unifi_5_10_x_upgrade
		 header
         wget https://dl.ui.com/unifi/5.10.20/unifi_sysvinit_all.deb || abort
         DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
         rm unifi_sysvinit_all.deb || abort
         unifi_update_finish;;
	  4|*)
	     echo "Cancelling the script!"
		 exit 1;;
    esac
  fi
fi

##########################################################################################################################################################################
#																																										 #
#																       5.9.x																							 #
#																																										 #
##########################################################################################################################################################################

if [[ $UNIFI = "5.9."* ]]
then
  clear
  echo -e "${GREEN}#########################################################################${RESET}"
  echo ""
  echo "  To what UniFi Network Controller version would you like to update?"
  echo -e "  Currently your UniFi Network Controller is on version ${WHITE}$UNIFI${RESET}"
  echo ""
  echo ""
  if [[ $UNIFI_RELEASE -ge "5929" ]]
  then
    UNIFI_VERSION='5.9.29'
    echo -e " [ ${WHITE}1${RESET} ]  |  5.10.20"
    echo -e " [ ${WHITE}2${RESET} ]  |  Cancel"
  else
    echo -e " [ ${WHITE}1${RESET} ]  |  5.9.29"
    echo -e " [ ${WHITE}2${RESET} ]  |  5.10.20"
    echo -e " [ ${WHITE}3${RESET} ]  |  Cancel"
  fi
  echo ""
  echo ""

  if [[ $UNIFI_VERSION = "5.9.29" ]]
  then
    read UPGRADE_VERSION
    case "$UPGRADE_VERSION" in
	1|51020|5.10.20)
	     unifi_update_start
		 unifi_5_10_x_upgrade
		 header
         wget https://dl.ui.com/unifi/5.10.20/unifi_sysvinit_all.deb || abort
         DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
         rm unifi_sysvinit_all.deb || abort
         unifi_update_finish;;
	  2|*)
	     echo "Cancelling the script!"
		 exit 1;;
    esac
  else
    read UPGRADE_VERSION
    case "$UPGRADE_VERSION" in
	  1|5929|5.9.29)
	     unifi_update_start
		 header
         wget https://dl.ui.com/unifi/5.8.30/unifi_sysvinit_all.deb || abort
         DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
         rm unifi_sysvinit_all.deb || abort
         unifi_update_finish;;
	  2|51020|5.10.20)
         unifi_update_start
		 header
         wget https://dl.ui.com/unifi/5.9.29/unifi_sysvinit_all.deb || abort
         DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
         rm unifi_sysvinit_all.deb || abort
         migration_check
		 unifi_5_10_x_upgrade
		 header
         wget https://dl.ui.com/unifi/5.10.20/unifi_sysvinit_all.deb || abort
         DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
         rm unifi_sysvinit_all.deb || abort
         unifi_update_finish;;
	  3|*)
	     echo "Cancelling the script!"
		 exit 1;;
    esac
  fi
fi

##########################################################################################################################################################################
#																																										 #
#																       5.10.x																							 #
#																																										 #
##########################################################################################################################################################################

if [[ $UNIFI = "5.10."* ]]
then
  if [ $UNIFI = "5.10.20" ]
  then
    clear
	clear
    echo -e "${GREEN}#####################################################${RESET}"
    echo -e "${GREEN}#                                                   #${RESET}"
    echo -e "${GREEN}#    ${RESET}Your UniFi Network Controller is already on    ${GREEN}#${RESET}"
    echo -e "${GREEN}#            ${RESET}the latest stable release!             ${GREEN}#${RESET}"
    echo -e "${GREEN}#                                                   #${RESET}"
    echo -e "${GREEN}#####################################################${RESET}"
	rm $0
	exit 1
  fi
  clear
  echo -e "${GREEN}#########################################################################${RESET}"
  echo ""
  echo "  To what UniFi Network Controller version would you like to update?"
  echo -e "  Currently your UniFi Network Controller is on version ${WHITE}$UNIFI${RESET}"
  echo ""
  echo ""
  echo -e " [ ${WHITE}1${RESET} ]  |  5.10.20"
  echo -e " [ ${WHITE}2${RESET} ]  |  Cancel"
  echo ""
  echo ""

  read UPGRADE_VERSION
  case "$UPGRADE_VERSION" in
	1|51020|5.10.20)
	   unifi_update_start
	   unifi_5_10_x_upgrade
	   header
       wget https://dl.ui.com/unifi/5.10.20/unifi_sysvinit_all.deb || abort
       DEBIAN_FRONTEND=noninteractive dpkg -i unifi_sysvinit_all.deb || abort
       rm unifi_sysvinit_all.deb || abort
       unifi_update_finish;;
	2|*)
	   echo "Cancelling the script!"
	   exit 1;;
  esac
fi