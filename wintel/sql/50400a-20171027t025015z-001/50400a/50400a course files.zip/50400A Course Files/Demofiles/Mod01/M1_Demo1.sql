USE QuantamCorp
GO
SELECT * FROM Production.Product                                   
