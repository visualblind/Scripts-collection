<?
/* This file is part of JFFNMS
 * Copyright (C) <2002-2005> Javier Szyszlican <javier@szysz.com>
 * This program is licensed under the GNU GPL, full terms in the LICENSE file
 */
    if (($break_by_host==1) or ($break_by_zone==1) or ($break_by_card==1))
	$html_current_x += ($html_separation_x*2) + $sizex;
?>
