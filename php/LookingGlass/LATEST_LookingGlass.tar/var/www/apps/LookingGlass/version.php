<?php
  $version["no"]="20040427";
  $version["fullname"]="Looking Glass";
  $version["homepage"]="http://de-neef.net/articles.php?id=2";
  $version["email"]="LookingGlass@de-neef.net";
  $version["author"]="Jurriaan de Neef";
?>
