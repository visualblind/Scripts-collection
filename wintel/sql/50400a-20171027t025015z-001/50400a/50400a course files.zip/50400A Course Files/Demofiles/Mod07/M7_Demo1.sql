/* Add a user to the server role*/

EXEC sp_addsrvrolemember 'Ben Darton', 'sysadmin';