USE master;
BACKUP DATABASE master TO DISK = 'D:\Data\master.bak'

USE master;
BACKUP DATABASE msdb TO DISK = 'D:\Data\msdb.bak'


USE master;
BACKUP DATABASE model TO DISK = 'D:\Data\model.bak'

