#!/bin/bash

/bin/chmod -R g+rwxs /mnt/storage/multimedia/Anime
/bin/chmod -R g+rwxs /mnt/storage/multimedia/Anime_Movies
/bin/chmod -R g+rwxs /mnt/storage/multimedia/HAnime
/bin/chmod -R g+rwxs /mnt/storage/multimedia/Video
