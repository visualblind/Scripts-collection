<?
/* This file is part of JFFNMS
 * Copyright (C) <2002-2005> Javier Szyszlican <javier@szysz.com>
 * This program is licensed under the GNU GPL, full terms in the LICENSE file
 */
    if ($first_time++!=0)
	$html_current_y += $sizey + $html_separation_y;

    $html_current_x = 0;
?>
