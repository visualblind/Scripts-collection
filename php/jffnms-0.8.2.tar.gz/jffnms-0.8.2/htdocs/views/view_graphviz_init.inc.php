<?
/* This file is part of JFFNMS
 * Copyright (C) <2002-2005> Javier Szyszlican <javier@szysz.com>
 * This program is licensed under the GNU GPL, full terms in the LICENSE file
 */
    $graphviz = "strict graph map {
	bgcolor=\"#$map_color\";
	margin=-0.03;
	ratio=fill;
	size=\"10.2,5.3\";
        overlap=false;
	node [fontsize=50];
	edge [len=3];
    "; 
?>
