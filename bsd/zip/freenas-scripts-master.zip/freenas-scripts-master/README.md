# freenas-scripts

Initially inspired from gist https://gist.github.com/takeshixx/7487381

Now split into multiple files for more fine grained scheduling.

I also added extra scripts that I use to manage my freenas jails
