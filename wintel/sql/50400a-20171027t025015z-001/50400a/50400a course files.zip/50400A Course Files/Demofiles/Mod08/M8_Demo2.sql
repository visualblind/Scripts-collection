SELECT wait_type, wait_time_ms
FROM sys.dm_os_wait_stats;
GO
