USE Mod07 ;
GO
GRANT SELECT ON SCHEMA::Calls TO peter
GO
GRANT SELECT ON SCHEMA::Customers TO peter
GO
GRANT SELECT ON Calls.CallDetails TO michael
GO
