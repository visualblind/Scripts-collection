USE master;
GO
EXEC sp_addlinkedserver 
   'NYC-SQL1\DEVELOPMENT',
   N'SQL Server'
GO
