<?php

if (!$_GET["nohead"]) { // used for printable reports
echo '
      </td>
  </tr>
</table>
<p>&nbsp;</p>
';
} // end if (!$_GET["nohead"])

echo '
</body>
</html>
	 ';
	 
?>

