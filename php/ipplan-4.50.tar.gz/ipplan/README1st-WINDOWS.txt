If you are a Windows user, use Wordpad to open and read the INSTALL
files. Notepad does not understand unix file format. IPplan works
just fine under Windows, but read the docs carefully stating with
INSTALL-WINDOWS

