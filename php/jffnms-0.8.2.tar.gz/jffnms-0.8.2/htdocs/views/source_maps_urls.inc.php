<?
/* This file is part of JFFNMS
 * Copyright (C) <2002-2005> Javier Szyszlican <javier@szysz.com>
 * This program is licensed under the GNU GPL, full terms in the LICENSE file
 */
    $urls = array(); 

    $urls["events"] = array("Events", "events.php?map_id=$id", "text.png");
    $urls["map"] = array ("View Interfaces", "frame_interfaces.php?break_by_card=0&break_by_zone=0events_update=0&map_id=$id", "int1.png");
?>
