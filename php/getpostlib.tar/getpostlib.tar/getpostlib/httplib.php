<?php


/*! This function performs a http POST query (i.e. form submission) and
 * returns the received response.
 \return FALSE Something went wrong, possibly the server refused your query or
 		the connection to the server failed.
 \return The response string.
*/
function http_post($server /**< Server's or proxie's host name or IP.*/,
		$port, /**< Server's or proxie's port */
	       	$url, /**< Should point to the URL on the server or full address if a proxy is used. */
		$cookie, /**< The optional cookie string. */
		$vars /**< Associative array of POST variables. Each key is the name of the variable and the value
			is the variable's content */
		) 
{
	$user_agent = "Mozilla/4.0 (compatible; MSIE 5.5; Windows 98)";


	$urlencoded = "";
	while (list($key,$value) = each($vars))
		$urlencoded.= urlencode($key) . "=" . urlencode($value) . "&";
	$urlencoded = substr($urlencoded,0,-1);	

	$content_length = strlen($urlencoded);

	$headers = "POST $url HTTP/1.1\r\nHost: $server\r\nAccept: */*\r\nAcceptLanguage: en-au\r\nConnection: close\r\nContent-Type: application/x-www-form-urlencoded\r\nUser-Agent: $user_agent\r\nCache-Control: no-cache\r\nCookie: {$cookie}\r\nContent-Length: $content_length\r\n\r\n";
	
	$fp = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
	
	if (!socket_connect($fp, $server, $port))
	{
		socket_close($fp);
		return false;
	}

 	socket_set_option($fp, SOL_SOCKET, SO_KEEPALIVE, TRUE);
	socket_send($fp, $headers, strlen($headers), 0);
	socket_send($fp, $urlencoded, strlen($urlencoded), 0);
	
	$ret = "";
	while ($rd = socket_read($fp, 1024))
	{
		$ret .= $rd;
	}
        
	socket_close($fp);

	$pos = strpos($ret, "\r\n\r\n");

	if (!is_bool($pos))
	{
		$ret = substr($ret, $pos);
	}

	return $ret;

}

/** This function performs a http GET query (i.e. download a web page or file) and
 * returns the received response.
 \return FALSE Something went wrong, possibly the server refused your query or
 		the connection to the server failed.
 \return The response string.
*/
function http_get($server,  /**< Server's or proxie's host name or IP.*/
		$port, /**< Server's or proxie's port */
		$url, /**< Should point to the URL on the server or full address if a proxy is used. */
		$cookie,  /**< The optional cookie string. */
		$additional_fields = "" /**< Optional string containing additional HTTP request fields, 
			each terminated by "\r\n". */)
{
	$user_agent = "Mozilla/4.0 (compatible; MSIE 5.5; Windows 98)";

	$headers = "GET $url HTTP/1.1\r\nAccept: */*\r\nAccept-Language: en-au\r\nUser-Agent: $user_agent\r\nHost: $server\r\nCookie: {$cookie}\r\nCache-Control: no-cache\r\nConnection: close\r\n{$additional_fields}\r\n";

	$fp = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
	if (!socket_connect($fp, $server, $port))
	{
		socket_close($fp);
		return FALSE;
	}

 	socket_set_option($fp, SOL_SOCKET, SO_KEEPALIVE, TRUE);
	socket_send($fp, $headers, strlen($headers), 0);
	
	$ret = "";
	while ($rd = socket_read($fp, 1024))
	{
		$ret .= $rd;
	}
        
	socket_close($fp);

	$pos = strpos($ret, "\r\n\r\n");

	if (!is_bool($pos))
	{
		$ret = substr($ret, $pos);
	}

	return $ret;
}

?>
